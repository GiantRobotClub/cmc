This wallpaper was made on a whim entirely in the computer.  I think it turned out well, don't you?  There are four Principalities cards shown:
Valian, the Reborn
Norlaan
the Terafang
and the Mitiring.

Prince Valian, Valian the Reborn, Valian son of Valiron, Valian Leader of the Paladin Army was away
during the CMC Prime timeframe.  During that time he was struck down in battle, but was revived
thanks to the amazing power of the Mitiring.  He was known after as "Valian, the Reborn" and his
story reached his home of Iridith before he did.

Oh, and by the way: VCHNEONBEATSX
