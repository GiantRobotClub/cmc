package webrunner.cardmaster;
import java.io.*;
import java.util.StringTokenizer;
public class CardmasterChatRoom{
	
	
	
//	private int roomnumber;
	public String name1;
	public String name2wait;
	public String name2;
	static String version = "a1.23-10";
	//public String messagebuffer;
	private String messagebuffername;

	public boolean empty;
	public boolean dead;
	int roomnumber = 0;
	private String[] messagebuffer;
	private int[] messageid;
	int[] waitcardlog1;
	int[] waitcardlog2;
	private int currentmessageid;
	private int currentindex;
	private int waitdraw1 = 0;
	private int waitdraw2 = 0;
	public boolean close = false;
	boolean ended = false;
	CardmasterLibrary deck1;
	CardmasterLibrary deck2;
	
	CardmasterServerCard h1[];
    CardmasterServerCard h2[];
    CardmasterServerCard m1[];
    CardmasterServerCard e1[];
    CardmasterServerCard m2[];
    CardmasterServerCard e2[];
	CardmasterServerCard returntohand;
	int returntohandplayer;
	CardmasterServerCard carddata[];
	String ability_intoplay[];
	String ability_command[];
	String ability_leaveplay[];
	String ability_endturn[];
	String ability_startturn[];
	String ability_attack[];
	String ability_afterattack[];
	String ability_defend[];
	
	int p1life = 300;
	int p2life = 300;
	int p1D = 1;
	int p1L = 1;
	int p1G = 1;
	int p2D = 1;
	int p2G = 1;
	int p2L = 1;
	int playerphase = 1;
	int winner = 0;
	int turncount = 1;
	// = 200;
	static int PHASE_DRAW = 0;
	static int PHASE_SAC = 1;
	static int PHASE_PLAY = 2;
	static int PHASE_ATTACK = 3;
	static int PHASE_DEFEND = 4;
	static int PHASE_RESOLVE = 5;
	int phase = PHASE_DRAW;
	public int waitcards1 = 0;
	public int waitcards2 = 0;
	
	boolean attacking = false;
	
	int[] attacker;
	int[] defender;
	int[] attackresult;
	boolean[] defenderlock;
	public void requestclose() {
		
		message("OVR#");	
		
	}
	boolean hasCardsInHand(int player) {
		if (player == 1) {
			for (int i=0;i<8;i++) if (!(h1[i].dummy)) return true;
			return false;	
		}	
		if (player == 2) {
			for (int i=0;i<8;i++) if (!(h2[i].dummy)) return true;
			return false;	
		}
		return false;		
		
	}
	void to_graveyard(CardmasterServerCard card) {
		int own = owner(card);
		System.out.println("Token: " + card.token);
		if (own==1) {
			
		if (! card.token ) deck1.addGrave(card.cardid);	
		}
		
		else if (own == 2) {
		if (! card.token )deck2.addGrave(card.cardid);
			
		}
		// no graveyard implementation yet.  Just discarding cards.
		card.copydata(new CardmasterServerCard());
		message(GRA());
		
	}
	
	
	int player_named(String playername) {
		if (playername.equals(name1)) return 1;
		return 2;		
	
	
}

	String player_named(int playername) {
		if (playername == 1) return name1;
		return name2;		
	
	
}

	boolean do_ability_on_slot(String play, int slot, String type, int tslot) {
		int player = player_named(play);
		if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
		if (!getSlot(player,slot,type).ability) return false; // has  ability
		if (!getSlot(player,slot,type).targets) return false; // ability target slots
		int cardid = getSlot(player,slot,type).cardid;
		int succode = runability(ability_command[cardid],player,null,getSlot(player,slot,type),tslot);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;
		if(success) message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		return success;
				
		
	}

	boolean do_ability_grave(String play, int slot, String type, int tcard) {
		int player = player_named(play);
		if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
		if (!getSlot(player,slot,type).ability) return false; // has  ability
		if (!getSlot(player,slot,type).targets) return false; // ability target slots
		AbilityTarget target = new AbilityTarget(player,tcard);
		int cardid = getSlot(player,slot,type).cardid;
		int succode = runability(ability_command[cardid],player,target,getSlot(player,slot,type),-1);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;
		if(success) { 
		message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		message(GRA());
		if (returntohand != null) 
		return_to_hand(returntohandplayer,returntohand);	
		
		
		
		}
		return success;
				
		
	}


	boolean do_ability_auto(String play, int slot,String type) {
		int player = player_named(play);
		if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
		if (!getSlot(player,slot,type).ability) return false; // has  ability
		if (!getSlot(player,slot,type).targeta) return false; // ability target all
		int cardid = getSlot(player,slot,type).cardid;
		
		int succode = runability(ability_command[cardid],player,null,getSlot(player,slot,type),-1);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;		
		
		if(success) message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		return success;
				
		
	}
	boolean do_ability_player(String play, int slot,String type,int tplayer) {
		int player = player_named(play);
	if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
	//	System.out.println("Isnt a dummy");
		if (!getSlot(player,slot,type).ability) return false; // has  ability
//		System.out.println("Has an ability");
		if (!getSlot(player,slot,type).targetp) return false; // ability target all
	
///		System.out.println("Do the ability now, yah!");
		int cardid = getSlot(player,slot,type).cardid;
		AbilityTarget target = new AbilityTarget(tplayer);
		int succode = runability(ability_command[cardid],player,target,getSlot(player,slot,type),-1);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;		
				if(success) message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		return success;
				
		
	}
	void intoplay_ability(int player, int slot, String type){
		if (getSlot(player,slot,type).dummy) return; // not likely to happen
		int cardid = getSlot(player,slot,type).cardid;
		if (ability_intoplay[cardid].startsWith("START")) {
			runability(ability_intoplay[cardid],player,null,getSlot(player,slot,type),-1);	
		}
		
	}
	void leaveplay_ability(int player, int slot, String type){
		if (getSlot(player,slot,type).dummy) return; // not likely to happen

		int cardid = getSlot(player,slot,type).cardid;
		if (ability_leaveplay[cardid].startsWith("START")) {
			runability(ability_leaveplay[cardid],player,null,getSlot(player,slot,type),-1);	
		}
		
	}	
		
	boolean do_ability_on_effect(String play, int slot, String type, int tplayer, int tslot) {
		int player = player_named(play);
		if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
		if (!getSlot(player,slot,type).ability) return false; // has  ability
		if (!getSlot(player,slot,type).targete) return false; // ability targets monsters
		int cardid = getSlot(player,slot,type).cardid;
		
		AbilityTarget target = new AbilityTarget(tplayer,tslot,"e");
		int succode = runability(ability_command[cardid],player,target,getSlot(player,slot,type),tslot);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;		
				if(success) message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		return success;
				
		
	}
	
	boolean do_ability_on_monster(String play, int slot, String type, int tplayer, int tslot) {
		int player = player_named(play);
		if (getSlot(player,slot,type) == null) return false;
		if (getSlot(player,slot,type).dummy) return false; // is a card
		if (!getSlot(player,slot,type).ability) return false; // has  ability
		if (!getSlot(player,slot,type).targetm) return false; // ability targets monsters
		int cardid = getSlot(player,slot,type).cardid;
		AbilityTarget target = new AbilityTarget(tplayer,tslot,"m");
		int succode = runability(ability_command[cardid],player,target,getSlot(player,slot,type),tslot);
		
		boolean success = true;
		if (succode == 0) success = false;
		if (succode == 1) getSlot(player,slot,type).dizzy = true;		
				if(success) message("MES#" + play + " uses ability of " + carddata[cardid].name);
		message(STN());
		message(STC());
		return success;
				
		
	}
	boolean in_play(int cardid) {
		boolean found = false;
		for (int i=0;i<5;i++) {
			if (e1[i].cardid == cardid) found = true;
			if (e2[i].cardid == cardid) found = true;
			if (m1[i].cardid == cardid) found = true;
			if (m2[i].cardid == cardid) found = true;
		}
		return found;	
			
	}


	boolean cast_spell_grave(String play, int handslot, int tcard) {
		int player = player_named(play);
		int cardid = 0;
	//	System.out.println("check has card.");
		if (player == 1) { if (h1[handslot].dummy) return false; cardid = h1[handslot].cardid; }
		else if (player == 2) { if (h2[handslot].dummy) return false; cardid = h2[handslot].cardid; }
		else return false;
	//	System.out.println("check dummy");
		if (carddata[cardid].dummy) return false; // is a card
	//	System.out.println("check s");
		if (!carddata[cardid].typecode.equals("s")) return false;
	//	System.out.println("check targetm");
		if (!carddata[cardid].targetg) return false; // ability targets monsters
		if (carddata[tcard].typecode.equals("m") && !carddata[cardid].targetm) return false;
		if (carddata[tcard].typecode.equals("e") && !carddata[cardid].targete) return false;
		
	//	System.out.println("check sufficent mana");
		if (!manacheck(player,cardid)) return false;
		
		
		AbilityTarget target = new AbilityTarget(player,tcard);
		int success = runability(ability_intoplay[cardid],player,target,null,-1);
		if(success != 0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
			if (returntohand != null) 
			return_to_hand(returntohandplayer,returntohand);
		}
		message(STN());
		message(STC());
		message(GRA());
		if (success == 0) return false;
		else return true;
				
		
	}

	boolean cast_spell_on_monster(String play, int handslot, int tplayer, int tslot) {
		int player = player_named(play);
		int cardid = 0;
	//	System.out.println("check has card.");
		if (player == 1) { if (h1[handslot].dummy) return false; cardid = h1[handslot].cardid; }
		else if (player == 2) { if (h2[handslot].dummy) return false; cardid = h2[handslot].cardid; }
		else return false;
	//	System.out.println("check dummy");
		if (carddata[cardid].dummy) return false; // is a card
	//	System.out.println("check s");
		if (!carddata[cardid].typecode.equals("s")) return false;
	//	System.out.println("check targetm");
		if (!carddata[cardid].targetm) return false; // ability targets monsters
	//	System.out.println("check sufficent mana");
		if (!manacheck(player,cardid)) return false;
		
		
		AbilityTarget target = new AbilityTarget(tplayer,tslot,"m");
		int success = runability(ability_intoplay[cardid],player,target,null,tslot);
		if(success != 0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
		}
		message(STN());
		message(STC());
		if (success == 0) return false;
		else return true;
				
		
	}
	boolean cast_spell_on_effect(String play, int handslot, int tplayer, int tslot) {
		int player = player_named(play);
		int cardid = 0;
		if (player == 1) { if (h1[handslot].dummy) return false; cardid = h1[handslot].cardid; }
		else if (player == 2) { if (h2[handslot].dummy) return false; cardid = h2[handslot].cardid; }
		else return false;
		if (carddata[cardid].dummy) return false; // is a card
		if (!carddata[cardid].typecode.equals("s")) return false;
		if (!carddata[cardid].targete) return false; // ability targets monsters
		if (!manacheck(player,cardid)) return false;
		
		
		AbilityTarget target = new AbilityTarget(tplayer,tslot,"e");
		int success = runability(ability_intoplay[cardid],player,target,null,tslot);
		if(success != 0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
		}
		message(STN());
		message(STC());
		if (success==0) return false;
		else return true; 
		
	}

	
		
	boolean cast_spell_on_slot(String play, int handslot, int tslot) {
		int player = player_named(play);
		int cardid = 0;
		if (player == 1) { if (h1[handslot].dummy) return false; cardid = h1[handslot].cardid; }
		else if (player == 2) { if (h2[handslot].dummy) return false; cardid = h2[handslot].cardid; }
		else return false;
		if (carddata[cardid].dummy) return false; // is a card
		if (!carddata[cardid].typecode.equals("s")) return false;
		if (!carddata[cardid].targets) return false; // ability targets monsters
		if (!manacheck(player,cardid)) return false;
		
		
	//	AbilityTarget target = new AbilityTarget(tplayer,tslot,"e");
		int success = runability(ability_intoplay[cardid],player,null,null,tslot);
		if(success!=0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
		}
		message(STN());
		message(STC());
		if (success==0) return false;
		else return true; 
				
		
	}

	boolean cast_spell_auto(String play, int handslot) {
		int player = player_named(play);
		int cardid = 0;
		if (player == 1) { if (h1[handslot].dummy) return false; cardid = h1[handslot].cardid; }
		else if (player == 2) { if (h2[handslot].dummy) return false; cardid = h2[handslot].cardid; }
		else return false;
		if (carddata[cardid].dummy) return false; // is a card
		if (!carddata[cardid].typecode.equals("s")) return false;
		if (!carddata[cardid].targeta) return false; // ability targets automatically
		if (!manacheck(player,cardid)) return false;
		
		
		
		int success = runability(ability_intoplay[cardid],player,null,null,-1);
		if(success != 0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
		}
		message(STN());
		message(STC());
		if (success==0) return false;
		else return true; 
				
		
	}

	boolean cast_spell_on_player(String play, int handslot, int tplayer) {
		System.out.println(play + " attempts to play from " + handslot + " to " + tplayer);
		int player = player_named(play);
		int cardid = 0;
		if (player == 1) { 
			if (h1[handslot].dummy) { System.out.println("Not in hand 1"); return false; }
			cardid = h1[handslot].cardid; 
		}
		else if (player == 2) { 
			if (h2[handslot].dummy) {System.out.println("Not in hand 2");  return false; }
			cardid = h2[handslot].cardid; 
		}
		else return false;
		System.out.println("Well, it's in the hand...");
		if (carddata[cardid].dummy) return false; // is a card
		System.out.println("It's not a dummy card..");
		if (!(carddata[cardid].typecode.equals("s"))) { System.out.println(carddata[cardid].typecode);return false;}
		System.out.println("It is a spell.");
		if (!(carddata[cardid].targetp)) return false; // ability targets players
		System.out.println("It targets players alright");
		if (!(manacheck(player,cardid))) return false;
		System.out.println("And you have enough mana..");
		
		
		AbilityTarget target = new AbilityTarget(tplayer);
		int success = runability(ability_intoplay[cardid],player,target,null,-1);
		System.out.println("Success: " + success);
		if(success!=0) { 
			message("MES#" + play + " casts spell " + carddata[cardid].name);
			message("SBC#" + carddata[cardid] + "#");
			manapay(player,cardid); 
			if (player ==1) to_graveyard(h1[handslot]);
			else if (player == 2) to_graveyard(h2[handslot]);
		}
		message(STN());
		message(STC());
		if (success==0) return false;
		else return true; 
				
		
	}
	void do_after_attack_abilities(int player) {
		for (int i=0;i<5;i++) {
			if (player==1) {
				//if (!m1[i].dummy) {
					int cardid = m1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_afterattack[cardid].startsWith("START")) {
					//	System.out.println("running ability m" + i + " "
						 runability(ability_afterattack[cardid],player,null,m1[i],-1);
					}

			//	}
			//	if (!e1[i].dummy) {
					 cardid = e1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_attack[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_afterattack[cardid],player,null,e1[i],-1);
					}

			//	}			

			}
			if (player==2) {
				//if (!m2[i].dummy) {
					int cardid = m2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_afterattack[cardid].startsWith("START")) {
						//System.out.println("running ability m" + i + " " 
						 runability(ability_afterattack[cardid],player,null,m2[i],-1);
					}

			//	}
				//if (!e2[i].dummy) {
					 cardid = e2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_afterattack[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_afterattack[cardid],player,null,e2[i],-1);
					}

				//}			

			}
		}	
	}

	void do_attack_abilities(int player) {
		for (int i=0;i<5;i++) {
			if (player==1) {
				//if (!m1[i].dummy) {
					int cardid = m1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_attack[cardid].startsWith("START")) {
					//	System.out.println("running ability m" + i + " "
						 runability(ability_attack[cardid],player,null,m1[i],-1);
					}

			//	}
			//	if (!e1[i].dummy) {
					 cardid = e1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_attack[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_attack[cardid],player,null,e1[i],-1);
					}

			//	}			

			}
			if (player==2) {
			//	if (!m2[i].dummy) {
					int cardid = m2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_attack[cardid].startsWith("START")) {
						//System.out.println("running ability m" + i + " " 
						 runability(ability_attack[cardid],player,null,m2[i],-1);
					}

				//}
			//	if (!e2[i].dummy) {
					 cardid = e2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_attack[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_attack[cardid],player,null,e2[i],-1);
					}

			//	}			

			}
		}	
	}

	void do_defend_abilities(int player) {
		for (int i=0;i<5;i++) {
			if (player==1) {
		//		if (!m1[i].dummy) {
					int cardid = m1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_defend[cardid].startsWith("START")) {
					//	System.out.println("running ability m" + i + " "
						 runability(ability_defend[cardid],player,null,m1[i],-1);
					}

			//	}
			//	if (!e1[i].dummy) {
					 cardid = e1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_defend[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_defend[cardid],player,null,e1[i],-1);
					}

			//	}			

			}
			if (player==2) {
			//	if (!m2[i].dummy) {
					int cardid = m2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_defend[cardid].startsWith("START")) {
						//System.out.println("running ability m" + i + " " 
						 runability(ability_defend[cardid],player,null,m2[i],-1);
					}

			//	}
			//	if (!e2[i].dummy) {
					 cardid = e2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_defend[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_defend[cardid],player,null,e2[i],-1);
					}

			//	}			

			}
		}	
	}
	void do_begin_turn_abilities(int player) {
		for (int i=0;i<5;i++) {
			if (player==1) {
			//	if (!m1[i].dummy) {
					int cardid = m1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_startturn[cardid].startsWith("START")) {
					//	System.out.println("running ability m" + i + " "
						 runability(ability_startturn[cardid],player,null,m1[i],-1);
					}

			//	}
			//	if (!e1[i].dummy) {
					cardid = e1[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_startturn[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_startturn[cardid],player,null,e1[i],-1);
					}

			//	}			

			}
			if (player==2) {
			//	if (!m2[i].dummy) {
					int cardid = m2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_startturn[cardid].startsWith("START")) {
						//System.out.println("running ability m" + i + " " 
						 runability(ability_startturn[cardid],player,null,m2[i],-1);
					}

			//	}
			//	if (!e2[i].dummy) {
					 cardid = e2[i].cardid;
					//System.out.println("Card ability: " + ability_startturn[cardid]);
					if (ability_startturn[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_startturn[cardid],player,null,e2[i],-1);
					}

			//	}			

			}
		}	
	}
	void do_end_turn_abilities(int player) {
		for (int i=0;i<5;i++) {
			if (player==1) {
			//	if (!m1[i].dummy) {
					int cardid = m1[i].cardid;
					//System.out.println("Card ability: " + ability_endturn[cardid]);
					if (ability_endturn[cardid].startsWith("START")) {
					//	System.out.println("running ability m" + i + " "
						 runability(ability_endturn[cardid],player,null,m1[i],-1);
					}

			//	}
			//	if (!e1[i].dummy) {
					cardid = e1[i].cardid;
					//System.out.println("Card ability: " + ability_endturn[cardid]);
					if (ability_endturn[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_endturn[cardid],player,null,e1[i],-1);
					}

			//	}			

			}
			if (player==2) {
			//	if (!m2[i].dummy) {
					int cardid = m2[i].cardid;
					//System.out.println("Card ability: " + ability_endturn[cardid]);
					if (ability_endturn[cardid].startsWith("START")) {
						//System.out.println("running ability m" + i + " " 
						 runability(ability_endturn[cardid],player,null,m2[i],-1);
					}

			//	}
			//	if (!e2[i].dummy) {
					 cardid = e2[i].cardid;
					//System.out.println("Card ability: " + ability_endturn[cardid]);
					if (ability_endturn[cardid].startsWith("START")) {
						//System.out.println("running ability e" + i + " " 
						runability(ability_endturn[cardid],player,null,e2[i],-1);
					}

			//	}			

			}
		}	
	}
	void sac_card(String playername, String type, int slot) {
		if (phase != PHASE_SAC) return;
		int num = player_named(playername);
		if (num == 1 && playerphase == 1) {
			if (waitcards1 > 0 ) return;
			//System.out.println("1 is discarding.  Type " + type + " slot " + slot);
			int sd = 0;
			int sl = 0;
			int sg = 0;
			CardmasterServerCard card = new CardmasterServerCard();
			if (type.equals("m")){
				card = m1[slot];

			} else if (type.equals("e")) {
				card = e1[slot];
				
			}
			if (card.dummy) return;
			message("MES#" + playername + " sacrifices " + card.name);
			sd = card.Dsac;
			sg = card.Gsac;
			sl = card.Lsac;
			destroy_card(num,type,slot);
				
				
				
			
			p1D+=sd;
			p1G+=sg;
			p1L+=sl;
			
			
			
		}	
		else if (num == 2 && playerphase == 2) {
			if (waitcards2 > 0 ) return;
			int sd = 0;
			int sl = 0;
			int sg = 0;
			System.out.println("2 is  Type " + type + " slot " + slot);
			CardmasterServerCard card = new CardmasterServerCard();
			if (type.equals("m")){
				card = m2[slot];

			} else if (type.equals("e")) {
				card = e2[slot];
				
			}
			if (card.dummy) return;
			message("MES#" + playername + " sacrifices " + card.name);
			//System.out.println("Killin that Card, Yo!");
			sd = card.Dsac;
			sg = card.Gsac;
			sl = card.Lsac;
			destroy_card(num,type,slot);
				
				
				
			
			p2D+=sd;
			p2G+=sg;
			p2L+=sl;
			
			
			
		}		
		
		
		
	}
	
	void discard_card(String playername, int handslot) {
		
		if (playername.equals(name1)) {
			if (waitcards1 >= 1) {
				if (!h1[handslot].dummy) {
					to_graveyard(h1[handslot]);
					waitcards1--;
					if (waitdraw1 > 0) { draw_card(1); waitdraw1--;}
					message(STC());
					message("DSS#1#");
				}	
			}	
	
		}
		else if (playername.equals(name2)) {
			if (waitcards2 >= 1) {
				if (!h2[handslot].dummy) {
					to_graveyard(h2[handslot]);
					waitcards2--;
					if (waitdraw2 > 0) { draw_card(2); waitdraw2--;}
					message(STC());
					message("DSS#2#");
		
				}	
			
			
			}
	
		}
	}
	
	CardmasterServerCard getSlot(int player, int slot, String type) {
		if ((player > 2) || (player < 1) || (slot < 0 )|| (slot > 4) )return null;
		if ((player == 1) && (type.equals("m"))) return m1[slot];
		if ((player == 2) && (type.equals("m"))) return m2[slot];
		if ((player == 1) && (type.equals("e"))) return e1[slot];
		if ((player == 2) && (type.equals("e"))) return e2[slot];				
		return null;
		
	}
	boolean isInPlay(int cardid) {
		for (int i =0;i<5;i++) {
			if (!(m1[i].dummy)) if (m1[i].cardid == cardid) return true;
			if (!(m2[i].dummy)) if (m2[i].cardid == cardid) return true;
			if (!(e1[i].dummy)) if (e1[i].cardid == cardid) return true;
			if (!(e2[i].dummy)) if (e2[i].cardid == cardid) return true;
			
			
		}	
		return false;
	}
   // PLAY AN EFFECT CARD
	int play_effect(String playername, int cardid,int slot, int handslot) {
		int player = 1;
		System.out.println(playername + " attempts to play " + cardid + " on " + slot);
	
		if (playername.equals(name2)) player = 2;
		if (!getSlot(player, slot, "e").dummy) return -1;
		if (getCard(cardid).dummy) return -20;
		if (!getCard(cardid).typecode.equals("e")) return -21;
		if ((playerphase != player) || (phase != PHASE_PLAY)) return -2;  
		if (!manacheck(player,cardid)) return -3;
		if (carddata[cardid].unique && isInPlay(cardid)) return -98;
		if (player == 1) { if (waitcards1 > 0 ) return -52;
			if (h1[handslot].cardid == cardid) {
				manapay(player,cardid);
				h1[handslot].copydata(new CardmasterServerCard());	
				int success= create_effect(player, slot, cardid);
				if (success == 1) message("MES#" + name1 + " plays " + carddata[cardid].name);
				return success;
				
			}
		}
		if (player == 2) { if (waitcards2 > 0 ) return -52;
			if (h2[handslot].cardid == cardid) {
				manapay(player,cardid);
				h2[handslot].copydata(new CardmasterServerCard());
					
				int success= create_effect(player, slot, cardid);
				if (success == 1) message("MES#" + name2 + " plays " + carddata[cardid].name);
				return success;
			}
		}	
		return -4;
	}
	
	// PLAY A MONSTER CARD
	int play_monster(String playername, int cardid,int slot, int handslot) {
		int player = 1;
		System.out.println(playername + " attempts to play " + cardid + " on " + slot);
		if (playername.equals(name2)) player = 2;
	//	System.out.println("Card is a " + getCard(cardid).typecode);
		if (!getSlot(player, slot, "m").dummy) return -1;
		if (getCard(cardid).dummy) return -20;
		
		if (!getCard(cardid).typecode.equals("m")) return -21;
		if ((playerphase != player) || (phase != PHASE_PLAY)) return -2;  
		if (!manacheck(player,cardid)) return -3;
		if (carddata[cardid].unique && isInPlay(cardid)) return -98;
		if (player == 1) { if (waitcards1 > 0 ) return -52;
			if (h1[handslot].cardid == cardid) {
				manapay(player,cardid);
				h1[handslot].copydata(new CardmasterServerCard());	
				int success= create_monster(player, slot, cardid);
				if (success == 1) message("MES#" + name1 + " plays " + carddata[cardid].name);
				return success;
				
			}
		}
		if (player == 2) { if (waitcards2 > 0 ) return -52;
			if (h2[handslot].cardid == cardid) {
				manapay(player,cardid);
				h2[handslot].copydata(new CardmasterServerCard());
					
				int success= create_monster(player, slot, cardid);
				if (success == 1) message("MES#" + name2 + " plays " + carddata[cardid].name);
				return success;
			
			}
		}	
		return -4;
	}
	
	// CREATE A MONSTER
	int create_monster(int player, int slot, int cardid) {
		if (carddata[cardid].dummy) return -10;
		if (!(carddata[cardid].typecode.equals("m"))) return -11;
		if (player == 1) {
			m1[slot].copydata(carddata[cardid]);
			intoplay_ability(player,slot,"m");
			return 1;
	
		}else if (player == 2) {
			m2[slot].copydata(carddata[cardid]);
			intoplay_ability(player,slot,"m");
			return 1;
		}
		System.out.println("What the hell? " + player);
		return -9;	
	}
	//create monster with attack/hp set.
	int create_monster(int player, int slot, int cardid, int attack, int lifepoints) {
		if (carddata[cardid].dummy) return -10;
		if (!(carddata[cardid].typecode.equals("m"))) return -11;
		if (player == 1) {
			m1[slot].copydata(carddata[cardid]);
			m1[slot].lifepoints = lifepoints;
			m1[slot].attack = attack;
			intoplay_ability(player,slot,"m");
			return 1;
	
		}else if (player == 2) {
			m2[slot].copydata(carddata[cardid]);
			m2[slot].lifepoints = lifepoints;
			m2[slot].attack = attack;
			intoplay_ability(player,slot,"m");
			return 1;
		}
		System.out.println("What the hell? " + player);
		return -9;	
	}
	// CREATE AN EFFECT
	int create_effect(int player, int slot, int cardid) {
		if (carddata[cardid].dummy) return -10;
		if (!(carddata[cardid].typecode.equals("e"))) return -11;
		if (player == 1) {
			e1[slot].copydata(carddata[cardid]);
			intoplay_ability(player,slot,"e");
			return 1;
	
		}else if (player == 2) {
			e2[slot].copydata(carddata[cardid]);
			intoplay_ability(player,slot,"e");
			return 1;
		}
		System.out.println("What the hell? " + player);
		return -9;	
	}
	int create_effect(int player, int slot, int cardid, int attack, int lifepoints) {
		if (carddata[cardid].dummy) return -10;
		if (!(carddata[cardid].typecode.equals("e"))) return -11;
		if (player == 1) {
			e1[slot].copydata(carddata[cardid]);
			e1[slot].lifepoints = lifepoints;
			e1[slot].attack = attack;
			intoplay_ability(player,slot,"e");
			return 1;
	
		}else if (player == 2) {
			e2[slot].copydata(carddata[cardid]);
			e2[slot].lifepoints = lifepoints;
			e2[slot].attack = attack;
			intoplay_ability(player,slot,"e");
			return 1;
		}
		System.out.println("What the hell? " + player);
		return -9;	
	}	
	
	boolean manacheck(int player, int cardid) {
		if (carddata[cardid].dummy) return false;
		if (player == 1) {
			if ((p1D >= carddata[cardid].Dcost) && 
				(p1G >= carddata[cardid].Gcost) && 
				(p1L >= carddata[cardid].Lcost)) return true;	
			
			
		}else if (player==2) {
			if ((p2D >= carddata[cardid].Dcost) && 
				(p2G >= carddata[cardid].Gcost) && 
				(p2L >= carddata[cardid].Lcost)) return true;			
			
		}
		
		return false;	
	}
	
	void manapay(int player, int cardid) {
		if (carddata[cardid].dummy) return;
		if (player == 1) {
		p1D-= carddata[cardid].Dcost;
		p1G-= carddata[cardid].Gcost;
		p1L-= carddata[cardid].Lcost;
		}
		if (player == 2) {
		p2D-= carddata[cardid].Dcost;
		p2G-= carddata[cardid].Gcost;
		p2L-= carddata[cardid].Lcost;
		}		
		
	}

	int return_to_hand(int playernumber, CardmasterServerCard thecard) {
		if (playernumber == 1) {
			
			for (int i =0;i<8;i++) {
				if (h1[i].dummy) {
					int card = thecard.cardid;
					if (card <10) return card;
					h1[i].copydata(getCard(card));
					System.out.println(playernumber + " (P1) Drawn card " + card);
					thecard.copydata(new CardmasterServerCard());
					message(STC());
					return card;
				}					
					
			}
		//	add_waiting(1,card);
			to_graveyard(thecard);
		}
		else if (playernumber == 2) {
			for (int i =0;i<8;i++) {
				if (h2[i].dummy) { 
					int card = thecard.cardid;
					if (card <10) return card;
					h2[i].copydata(getCard(card));
					System.out.println(playernumber + " (P2) Drawn card " + card);
					thecard.copydata(new CardmasterServerCard());
					message(STC());
					
					return card;
				}					
					
			}
		//	add_waiting(2,card);
			to_graveyard(thecard);
		}		
		return -1;
	}

	int draw_card(int playernumber) {
		if (playernumber == 1) {
			
			for (int i =0;i<8;i++) {
				if (h1[i].dummy) {
					int card = deck1.drawCard();
					if (card == -1) endduel(2);
					if (card <10) return card;
					h1[i].copydata(getCard(card));
					System.out.println(playernumber + " (P1) Drawn card " + card);
					message(STC());
					if (waitcards1 > 0)  message("MDN#" + playernumber + "#");
					return card;
				}					
					
			}
			waitdraw1++;
			req_discard(1);
		}
		else if (playernumber == 2) {
			for (int i =0;i<8;i++) {
				if (h2[i].dummy) { 
					int card = deck2.drawCard();
					if (card == -1) endduel(1);
					if (card <10) return card;
					h2[i].copydata(getCard(card));
					System.out.println(playernumber + " (P2) Drawn card " + card);
					message(STC());
					if (waitcards2 > 0)  message("MDN#" + playernumber + "#");
					return card;
				}					
					
			}
			waitdraw2++;
			req_discard(2);
		}		
		return -1;
	}
	public int numCardsInHand(int player) {
		int count = 0;
		if (player ==1) {
			for (int i=0;i<8;i++) if (!(h1[1].dummy)) count++;
			return count;
		}
			
		if (player ==2) {
			for (int i=0;i<8;i++) if (!(h1[2].dummy)) count++;
			return count;
		}
		return 0;
		
	}
	void req_discard(int player) {
		if (hasCardsInHand(player)) {
		message("MDN#" + player + "#");
		if (player==1) { waitcards1++; }
		else {waitcards2++;}
		}
		
	}
	
	void init_game() {
		
		//randomly switch name1 and name2
		
			h1 = new CardmasterServerCard[8];
			h2 = new CardmasterServerCard[8];
			m1 = new CardmasterServerCard[5];
			m2 = new CardmasterServerCard[5];
			e1 = new CardmasterServerCard[5];
			e2 = new CardmasterServerCard[5];
			

		for (int i = 0;i<5;i++) {
		m1[i] = new CardmasterServerCard();
		m2[i] = new CardmasterServerCard();
		e2[i] = new CardmasterServerCard();
		e1[i] = new CardmasterServerCard();
		h1[i] = new CardmasterServerCard();
		h2[i] = new CardmasterServerCard();
	
		}
		for (int i = 5; i<8;i++) {
		h1[i] = new CardmasterServerCard();
		h2[i] = new CardmasterServerCard();
		}	
		
		deck1 = new CardmasterLibrary(name1);
		if (deck1.created == false) requestclose();
		deck1.PrepareDeck();
		deck2 = new CardmasterLibrary(name2);
		if (deck2.created == false) requestclose();
		
		deck2.PrepareDeck();
		
		draw_card(1);
		draw_card(1);
		draw_card(1);
		draw_card(1);
		draw_card(1);
		draw_card(2);
		draw_card(2);
		draw_card(2);
		draw_card(2);
		draw_card(2); // initial hands.
		
		doPhaseStuff();
	}
	
	CardmasterServerCard getCard(int cardid) {
		System.out.println("Getting card with id " + cardid);
		CardmasterServerCard newcard = new CardmasterServerCard();
		newcard.copydata(carddata[cardid]);
		return newcard;
		
		
	}
	void loadCardData() {
		carddata = new CardmasterServerCard[CardmasterData.NUMBER_OF_CARDS];
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "cards.csc");
			BufferedReader in = new BufferedReader(reader);
			
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
				if (cardid >= 10) carddata[cardid] = new CardmasterServerCard(inputLine);
				
			//	System.out.println(carddata[cardid]);
				
				
			}
			
			
			reader.close();
			
			
		}
		catch (Exception e) {
			e.printStackTrace();}	
		
		
		
	}
	
	void loadAbilityData() { // Load card abilities.
		ability_intoplay = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_command = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_leaveplay = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_endturn = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_startturn = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_defend = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_attack = new String[CardmasterData.NUMBER_OF_CARDS];
		ability_afterattack = new String[CardmasterData.NUMBER_OF_CARDS];
		for (int i = 0;i<CardmasterData.NUMBER_OF_CARDS;i++) {
			ability_intoplay[i] = "NCODE;";	
			ability_command[i] = "NCODE;";	
			ability_leaveplay[i] = "NCODE;";	
			ability_endturn[i] = "NCODE;";	
			ability_startturn[i] = "NCODE;";
			ability_defend[i] = "NCODE;";
			ability_attack[i] = "NCODE;";
			ability_afterattack[i] = "NCODE;";				
			
		}	
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "abilities.csc");
			BufferedReader in = new BufferedReader(reader);
				
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
			//	System.out.println("Found ability for card "+  cardid);
				String test = token.nextToken();
			//	System.out.println(test);
				if (cardid >= 10) ability_intoplay[cardid] = test;
				test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_leaveplay[cardid] = test;
				test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_endturn[cardid] = test;
				test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_startturn[cardid] = test;
				 test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_attack[cardid] = test;
				 test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_afterattack[cardid] = test;
				 test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_defend[cardid] = test;
				test = token.nextToken();//System.out.println(test);
				if (cardid >= 10) ability_command[cardid] = test;
			//	System.out.println(carddata[cardid]);
				
				
			}
			reader.close();
				
				
		}
		catch (Exception e) {
				e.printStackTrace();}		
		
		
	}
	
	void nextPhase(String name) {
		int no;
		if (name.equals(name1)) {
			no = 1;
		} else { no = 2; }
		
		if (no == playerphase && phase != 4) {
			goNextPhase();	
			
		}
		else if (no != playerphase && phase == 4) {
			goNextPhase();	
			
		}
		else return;
	
	}	
	
	void attack_command(String playername, int slot, int eslot, int type) {
		if (type == 1) {
			attack(player_named(playername),slot);
			
		}
		else if (type == 2) {
			attack(player_named(playername),slot,eslot);
		}
		else if (type == 3) {
			defend(player_named(playername),slot,eslot);
		}		
	}
	
	// attack general
	void attack(int player, int slot) {
		if (!(playerphase == player && phase == PHASE_ATTACK)) return;
		if (player == 1) {
			if (m1[slot].dizzy || m1[slot].dummy) return;
			if (m1[slot].mtype.equals("wall")) return;
			if (attacker[slot+1] > 0 && attacker[slot+1]<6) { defender[attacker[slot+1]] = 0; } // reset defender
			attacker[slot+1] = 6;		
	
		}	
		else if (player == 2) {
			if (m2[slot].dizzy || m2[slot].dummy) return;
			if (m2[slot].mtype.equals("wall")) return;
			if (attacker[slot+1] > 0 && attacker[slot+1]<6) { defender[attacker[slot+1]] = 0; } // reset defender
			attacker[slot+1] = 6;		
	
		}	
	}
	
	//attack monster
	void attack(int player, int slot, int eslot) {
		if (!(playerphase == player && phase == PHASE_ATTACK)) return;
		if (player == 1) {
			if (m1[slot].dizzy || m1[slot].dummy) return;
			if (m1[slot].mtype.equals("wall")) return;
			if (m2[eslot].dummy) return;
			if (attacker[slot+1] > 0 && attacker[slot+1]<6) { attacker[defender[attacker[slot+1]]] = 0; defender[attacker[slot+1]] = 0; defenderlock[attacker[slot+1]] = false; } // reset defender
			attacker[slot+1] = eslot+1;
			defender[eslot+1] = slot+1 ;	
			defenderlock[eslot+1] = true;// lock defender, so they cant change
		}	
		else if (player == 2) {
			if (m2[slot].dizzy || m2[slot].dummy) return;
			if (m2[slot].mtype.equals("wall")) return;
			if (m1[eslot].dummy) return;
			if (attacker[slot+1] > 0 && attacker[slot+1]<6) {  attacker[defender[attacker[slot+1]]] = 0; defender[attacker[slot+1]] = 0; defenderlock[attacker[slot+1]] = false; } // reset defender
			attacker[slot+1] = eslot+1;
			defender[eslot+1] = slot+1;	 
			defenderlock[eslot+1] = true;// lock defender, so they cant change	
		}			
		
		
	}
	
	//Defend 
	void defend(int player, int slot, int eslot) {
		if (!(playerphase != player && phase == PHASE_DEFEND))  { 
		System.out.println("not defending because incorrect phase or player"); return; }
		if (player == 1) {
			if (m1[slot].dizzy || m1[slot].dummy){ 
		System.out.println("Dummy"); return; }
		} else if (player == 2) {
			if (m2[slot].dizzy || m2[slot].dummy) { 
		System.out.println("Dummy"); return; }
			
		}
			if (defenderlock[slot+1]) { 
		System.out.println("Locked"); return; } // defender is locked
			if (attacker[eslot+1] == 0){ 
		System.out.println("Not attacking"); return; } // chosen defender isn't attacking 
			if (defender[slot+1] > 0) {attacker[defender[slot+1]] = 6;} // reset attacker.
			defender[slot+1] = eslot+1;
			attacker[eslot+1] = slot+1;
		
			System.out.println("Will defend");
			

	
	}
	
	int damage_player(int player, int amount) {
		if (player ==1) { p1life-= amount;message("MES#" + name1 + " takes " + amount + " damage!");
return p1life;}
		else if (player==2) { p2life-= amount; message("MES#" + name2 + " takes " + amount + " damage!");return p2life; }
		System.out.println("ERROR: DAMAGE_PLAYER");
		return 999;
		
		
	}
	void destroy_card(int player, String type, int slot) {
		int cardid = getSlot(player,slot,type).cardid;
		leaveplay_ability(player, slot, type);
		message("MES#" + carddata[cardid].name + " is destroyed!");
		to_graveyard(getSlot(player,slot,type));	
		
		
	}
	void endduel (int player) {
		if (!ended) {
		
		loadUserData();
		String winner = null;
		String loser = null;
		ended = true;
		if (player==1) { winner = name1; loser = name2; }
		else if (player==2) { winner = name2; loser = name1; }
		if (!((winner == null) || (loser == null))) {
		CardmasterUser winuser = loadUser(winner);
		CardmasterUser lossuser = loadUser(loser);
		double regular_points = 75;
		double loserRatio = (double)(lossuser.wins) - (double)((lossuser.losses)/3);
		double winnerRatio = (double)(winuser.wins) - (double)((winuser.losses)/3);
		if (loserRatio < 1) loserRatio = 1;
		if (winnerRatio <1) winnerRatio = 1;
		double bothRatio = loserRatio / winnerRatio;
		int pointswon = (int)(regular_points * bothRatio);
		if (pointswon < 0) pointswon = 0;
	//	System.out.println("Points won:" pointswon);
		double otherRatio = winnerRatio / loserRatio;
		int pointsloser = (int)((regular_points / 6) * otherRatio);
		if (pointsloser <0) pointsloser = 0;
	boolean success = 	userpatch(loser,"addp",pointsloser,"x") &&
		userpatch(winner, "addp",pointswon,"x") &&
		userpatch(winner,"addw",1,"x") &&
		userpatch(loser,"addl",1,"x");
		if (!success) System.out.println("ERROR.");
		message("WIN#" + player + "#" + pointswon + "#" + pointsloser + "#");
	//	winuser.wins += 1;
	//	saveusers();
		}
		//ante
		requestclose();	
		}
		
	}
	public void giveup(String name){ 
		if (name.equals(name1)) {
			message("CHA#SYSTEM#" + name1 + " Has timed out.");
			endduel(2);
			
			}
		else if (name.equals(name2)) {
			message("CHA#SYSTEM#" + name2 + " Has timed out.");
			endduel(1);
				
		}
		else endduel(0);
	
	
	}
	int damage_monster(int player, int slot, int amount) {
			int templife = amount - getSlot(player,slot,"m").lifepoints;
			getSlot(player,slot,"m").lifepoints -= amount;
			getSlot(player,slot,"m").healfor = amount;
			message("MES#" + getSlot(player,slot,"m").name + " takes " + amount + " damage!");
			if (getSlot(player,slot,"m").lifepoints <= 0) destroy_card(player, "m", slot);
			return templife;
	}
	boolean containscolor(int color, int checkcolor) {
		if (checkcolor == 14) return true;
		if (color == checkcolor) return true;
		if (color == 6 && (checkcolor ==2 || checkcolor==4 )) return true;
		if (color == 10 && (checkcolor ==2 || checkcolor==8 )) return true;
		if (color == 12 && (checkcolor ==4 || checkcolor==8 )) return true;
		return false;	
	}	
	boolean matchcard(String a, String c, String d, 
		CardmasterServerCard card, CardmasterServerCard self, AbilityTarget target) {
		if (card.dummy) return false;
		boolean abs = false;
		boolean selfc = false;
		boolean targ = false;
		boolean matchtype = true;
		boolean matchname = true;
		boolean matchedtype = false;
		boolean matchedname = false;
		boolean match = false;
		boolean isinset = false;
		boolean attackers = false;
		boolean matchcolor = false;
		int mcolor = 0;
		if (a.equals("all")) { abs = true; selfc = true; }
		else if (a.equals("trg")) { 
			targ = true;
		}
		else if (a.equals("abs")) { abs = true; }
		else if (a.equals("slf")) { selfc = true; }
		else if (a.equals("atk")) { attackers= true; abs = true; selfc = true; }
		
		if (c.equals("none")) { matchtype = false; matchedtype = true; }
		if (d.equals("none")) { matchname = false; matchedname = true; }
		if (d.startsWith("col[")) {
			mcolor = Integer.parseInt(d.substring(4));
			matchname= false; matchedname = true;
			matchcolor = true;
				
			
		}
		if (matchcolor) {
			
			if (!containscolor(card.colorcode,mcolor)) return false;	
			
		}
		if (attackers) {
			System.out.println("Checking attacking..");
			if (!(isAttacking(card))) return false;
			
		}
		
		if (targ) {
			if (target == null) return false;
			if (!target.isCard) return false;
			if (target.getCard() == card) isinset = true;	
			
			
		}
		if (selfc) {
			if (card == self) isinset = true;	
			
		}
		if (abs) {
				if (card != self) isinset = true;
			
		}
			
		
		if (matchtype) {
			if (card.mtype.equals(c)) matchedtype = true;	
		}
		if (matchname) {
			if (card.name.equals(c)) matchedname = true;
			
		}
		return (isinset && matchedname && matchedtype);

	}
	

	int getvalue(String exp, int countvalue, int player, AbilityTarget targt, CardmasterServerCard self) {
		int tplayer = 0;
		if (targt != null)
			if (targt.isPlayer) tplayer = targt.getPlayer();
			
		StringTokenizer exptoken = new StringTokenizer(exp,":");
		if (!exptoken.hasMoreTokens()) return Integer.parseInt(exp);
		String cmd = exptoken.nextToken();
		if (cmd.equals("cnt")) {
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)countvalue * multiplier);
		}else if (cmd.equals("lif")) { //Lifepoints
			if (!exptoken.hasMoreTokens()) return 0;
			boolean owner = false;
			boolean target = false;
			boolean opon = false;
			String playerd = exptoken.nextToken();
			if (playerd.equals("both")) { owner = true; opon = true; }
			else if (playerd.equals("ownr")) { owner = true; }
			else if (playerd.equals("opon")) { opon = true; }
			else if (playerd.equals("targ")) { target = true; }
			int life = 0;
			if (owner) {
				if (player ==1) {
					life+= p1life;	
				}else { life+= p2life; }	
			}
			if (opon) {
				if (player ==2) {
					life+= p1life;	
				}else { life+= p2life; }				
			}
			if (target) {
				if (tplayer ==1) {
					life+= p1life;	
				}else if (tplayer == 2){ life+= p2life; }				
			}
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)life * multiplier);			
		}else if (cmd.equals("dek")) { //Deck value
			if (!exptoken.hasMoreTokens()) return 0;
			boolean owner = false;
			boolean target = false;
			boolean opon = false;
			String playerd = exptoken.nextToken();
			if (playerd.equals("both")) { owner = true; opon = true; }
			else if (playerd.equals("ownr")) { owner = true; }
			else if (playerd.equals("opon")) { opon = true; }
			else if (playerd.equals("targ")) { target = true; }
			int v = 0;
			if (owner) {
				if (player ==1) {
					v+= deck1.deckcards;	
				}else { v+=deck2.deckcards; }	
			}
			if (opon) {
				if (player ==2) {
					v+= deck1.deckcards;	
				}else { v+= deck2.deckcards; }				
			}
			if (target) {
				if (tplayer ==1) {
					v+= deck1.deckcards;	
				}else if (tplayer == 2){ v+= deck2.deckcards; }				
			}
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)v * multiplier);
		}else if (cmd.equals("mad")) { // D mana value.
			if (!exptoken.hasMoreTokens()) return 0;
			boolean owner = false;
			boolean target = false;
			boolean opon = false;
			String playerd = exptoken.nextToken();
			if (playerd.equals("both")) { owner = true; opon = true; }
			else if (playerd.equals("ownr")) { owner = true; }
			else if (playerd.equals("opon")) { opon = true; }
			else if (playerd.equals("targ")) { target = true; }
			int v = 0;
			if (owner) {
				if (player ==1) {
					v+= p1D;	
					
				}else { v+=p2D; }	
			}
			if (opon) {
				if (player ==2) {
					v+= p1D;	
				}else { v+= p2D; }				

			}
			if (target) {
				if (tplayer ==1) {
					v+= p1D;	
				}else if (tplayer == 2){ v+= p2D; }				
			}
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)v * multiplier);
		}else if (cmd.equals("mag")) { // G mana value.
			if (!exptoken.hasMoreTokens()) return 0;
			boolean owner = false;
			boolean target = false;
			boolean opon = false;
			String playerd = exptoken.nextToken();
			if (playerd.equals("both")) { owner = true; opon = true; }
			else if (playerd.equals("ownr")) { owner = true; }
			else if (playerd.equals("opon")) { opon = true; }
			else if (playerd.equals("targ")) { target = true; }
			int v = 0;
			if (owner) {
				if (player ==1) {
					v+= p1G;	
					
				}else { v+=p2G; }	
			}
			if (opon) {
				if (player ==2) {
					v+= p1G;	
				}else { v+= p2G; }				

			}
			if (target) {
				if (tplayer ==1) {
					v+= p1G;	
				}else if (tplayer == 2){ v+= p2G; }				
			}
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)v * multiplier);
		}else if (cmd.equals("mal")) { // l mana value.
			if (!exptoken.hasMoreTokens()) return 0;
			boolean owner = false;
			boolean target = false;
			boolean opon = false;
			String playerd = exptoken.nextToken();
			if (playerd.equals("both")) { owner = true; opon = true; }
			else if (playerd.equals("ownr")) { owner = true; }
			else if (playerd.equals("opon")) { opon = true; }
			else if (playerd.equals("targ")) { target = true; }
			int v = 0;
			if (owner) {
				if (player ==1) {
					v+= p1L;	
					
				}else { v+=p2L; }	
			}
			if (opon) {
				if (player ==2) {
					v+= p1L;	
				}else { v+= p2L; }				

			}
			if (target) {
				if (tplayer ==1) {
					v+= p1L;	
				}else if (tplayer == 2){ v+= p2L; }				
			}
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)v * multiplier);
		}else if (cmd.equals("mlp")) {// monster life point match sum
			if (!exptoken.hasMoreTokens()) return 0;
			String a = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String b = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String c = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String d = exptoken.nextToken();
			int player1 = 0;
			int player2 = 0;
			int val = 0;
			if (b.startsWith("b")) { player1 = 1; player2 = 2; }
			if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
			if (b.startsWith("s")) { player1 = player; player2 = player; }
			
			for (int i=0;i<5;i++) {
				if (player1==1) if (matchcard(a, c,d, m1[i], self, targt)) { val+= m1[i].lifepoints;	}
				if (player1==1) if (matchcard(a, c,d, e1[i], self, targt)) { val+= e1[i].lifepoints;	}
								
				if (player2==2) if (matchcard(a, c,d, m2[i], self, targt)) { val+= m2[i].lifepoints;}
				if (player2==2) if (matchcard(a, c,d, e2[i], self, targt)) { val+= e2[i].lifepoints;}
												
				
				
			}	
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier = Double.parseDouble(exptoken.nextToken());
			return (int)((double)val * multiplier);
			
		}else if (cmd.equals("map")) { // monster attack point match sum
			if (!exptoken.hasMoreTokens()) return 0;
			String a = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String b = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String c = exptoken.nextToken();if (!exptoken.hasMoreTokens()) return 0;
			String d = exptoken.nextToken();
			int player1 = 0;
			int player2 = 0;
			int val = 0;
			if (b.startsWith("b")) { player1 = 1; player2 = 2; }
			if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
			if (b.startsWith("s")) { player1 = player; player2 = player; }
			if (b.startsWith("e")) { player1 = 1; player2 = 2; }
			for (int i=0;i<5;i++) {
				if (player1==1) if (matchcard(a,c,d, m1[i], self, targt)) { val+= m1[i].attack;}
				if (player2==2) if (matchcard(a,c,d, m2[i], self, targt)) { val+= m2[i].attack;}
								
				if (player1==1) if (matchcard(a,c,d, e1[i], self, targt)) { val+= e1[i].attack;}
				if (player2==2) if (matchcard(a,c,d, e2[i], self, targt)) { val+= e2[i].attack;}
								
								
				
			}	
			if (!exptoken.hasMoreTokens()) return 0;
			double multiplier =Double.parseDouble(exptoken.nextToken());
			return (int)((double)val * multiplier);
			
		}				
		
		return Integer.parseInt(exp);	
	}
	int findSlotNumber(CardmasterServerCard card) {
		for (int i = 0;i<5;i++) {
			if (m1[i] == card) return i;
			if (m2[i] == card) return i;
			if (e1[i] == card) return i;
			if (e2[i] == card) return i;
		}							
					
		
		
		return -1;
	}
	// player is owner.
	int runability(String abilitycode, int player, AbilityTarget target, CardmasterServerCard self, int targetslot) {
		// this assumes the ability can be played.  If there's an error, it returns
		// FALSE and the ability is considered failed.
		System.out.println(abilitycode);
		int costd = 0;
		int costg = 0;
		int costl = 0;
		int count = 0;
		int tplayer = 0;
		if (target != null) if (target.isPlayer) tplayer = target.getPlayer();
		boolean started = true;
		StringTokenizer token = new StringTokenizer(abilitycode,";");
		while (token.hasMoreTokens()) {
			String command = token.nextToken();
			if (command.startsWith("NCODE")) return 0;
			else if (command.startsWith("START")) continue;
			else if (command.startsWith("END")) return 1;
			else if (command.startsWith("DEND")) return 2;
			else if (command.startsWith("COSTD")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String cmd = cmdtoken.nextToken();
				costd = getvalue(cmd, count, player, target, self);
				if (player == 1 && costd > p1D) return 0;
				if (player == 2 && costd > p2D) return 0;		
			}else if (command.startsWith("COSTG")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String cmd = cmdtoken.nextToken();
				costg = getvalue(cmd, count, player, target, self);
				if (player == 1 && costg > p1G) return 0;	
				if (player == 2 && costg > p2G) return 0;
			}else if (command.startsWith("COSTL")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String cmd = cmdtoken.nextToken();
				costl = getvalue(cmd, count, player, target, self);
				if (player == 1 && costl > p1L) return 0;	
				if (player == 2 && costl > p2L) return 0;
			}else if (command.equals("REQ")) {
				if (player ==1) {
					p1L-= costl;
					p1G-= costg;
					p1D-= costd;
					}	
				else if (player ==2) {
					p2L-= costl;
					p2G-= costg;
					p2D-= costd;
					}				
			}			
			else if (command.startsWith("ISDIZ")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				boolean dizzy = true;		
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							if (!m1[i].dizzy) dizzy = false;	
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							if (!m2[i].dizzy) dizzy = false;	
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							if (!e1[i].dizzy) dizzy = false;	
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							if (!e2[i].dizzy) dizzy = false;	
						}
					}
				}
				if (!dizzy) return 0;								
			}				
			else if (command.startsWith("NODIZ")) { // NODIZ requirement
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				boolean dizzy = true;		
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							if (m1[i].dizzy) dizzy = false;	
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							if (m2[i].dizzy) dizzy = false;	
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							if (e1[i].dizzy) dizzy = false;	
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							if (e2[i].dizzy) dizzy = false;	
						}
					}
				}
				if (!dizzy) return 0;								
			}
			else if (command.startsWith("CRDTT")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command		
				if (target == null) return 0;
				if (!target.isCard ) return 0;
				if (!(target.getCard().typecode.equals("m"))) return 0;
				String type = cmdtoken.nextToken();
				if (!(target.getCard().mtype.equals(type))) return 0;	
			}			
			else if (command.startsWith("CRDTN")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command		
				if (target == null) return 0;
				if (!target.isCard ) return 0;
				String type = cmdtoken.nextToken();
				if (!(target.getCard().name.equals(type))) return 0;	
			}			


			else if (command.startsWith("COUNT")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				count = 0;
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							count++;
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							count++;
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							count++;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							count++;
						}
					}
				}
				System.out.println("Count value: " + count);	
			}			
			else if (command.startsWith("TEMPV")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command		

				String val = cmdtoken.nextToken();
				count =  getvalue(val, count, player, target, self);	
			}
			else if (command.startsWith("DAMAG")) { // Damage Card.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int player1 = 0;
				int player2 = 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
			//	System.out.println("player1:" + player1 + " player2:" + player2);
			//	boolean dizzy = true;		
				for (int i=0;i<5;i++) {
					
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							
							damage_monster(1,i,amount);
						//	message("MES#Monster is damaged...");
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							damage_monster(2,i,amount);	
					//		message("MES#Monster is damaged...");
						}
										
				}
			//	if (!dizzy) return 0;								
			}
			else if (command.startsWith("DESTR")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							destroy_card(1,"m",i);
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							destroy_card(2,"m",i);
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							destroy_card(1,"e",i);
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							destroy_card(2,"e",i);
						}
					}
				}	
			}		
			else if (command.startsWith("HEALD")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").lifepoints += getSlot(1,i,"m").healfor;
							getSlot(1,i,"m").healfor = 0;
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").lifepoints += getSlot(2,i,"m").healfor;
							getSlot(2,i,"m").healfor = 0;
						}
					}
					/*if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, targt)) { 
							getSlot(1,i,"e").lifepoints += getSlot(1,i,"m").healfor;
							getSlot(1,i,"m").healfor = 0;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, targt)) { 
							getSlot(2,i,"e").lifepoints += getSlot(1,i,"m").healfor;
							getSlot(2,i,"e").healfor = 0;
						}
					}*/
				 }
			}			
							
			else if (command.startsWith("A-SET")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").attack = amount;
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").attack = amount;;
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").attack = amount;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").attack = amount;
						}
					}
				}			
			}
			else if (command.startsWith("AMODF")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").attack += amount;
							if (getSlot(1,i,"m").attack < 0) getSlot(1,i,"m").attack = 0;
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").attack += amount;
							if (getSlot(2,i,"m").attack < 0) getSlot(2,i,"m").attack = 0;
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").attack += amount;
							if (getSlot(1,i,"m").attack < 0) getSlot(1,i,"m").attack = 0;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").attack += amount;
							if (getSlot(2,i,"e").attack < 0) getSlot(2,i,"e").attack = 0;
						}
					}
				}			
			}
			else if (command.startsWith("L-SET")) {
				System.out.println("Life set");
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				if (amount <= 1) amount = 1;
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").lifepoints = amount;
							
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").lifepoints = amount;;
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").lifepoints = amount;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").lifepoints = amount;
						}
					}
				}			
			}	
			else if (command.startsWith("LMODF")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").lifepoints += amount;
							if (getSlot(1,i,"m").lifepoints < 1) getSlot(1,i,"m").lifepoints = 1;
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").lifepoints += amount;
							if (getSlot(2,i,"m").lifepoints < 1) getSlot(2,i,"m").lifepoints = 1;
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").lifepoints += amount;
							if (getSlot(1,i,"m").lifepoints < 1) getSlot(1,i,"m").lifepoints = 1;
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").lifepoints += amount;
							if (getSlot(2,i,"e").lifepoints < 1) getSlot(2,i,"e").lifepoints = 1;
						}
					}
				}			
			}
			else if (command.startsWith("DIZZY")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();//if (!cmdtoken.hasMoreTokens()) return 0;
				//int amount = getValue(cmdtoken.nextToken(),count,player,target,self);
				
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").dizzy = true;
							
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").dizzy = true;
						
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").dizzy = true;
							
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").dizzy = true;
						
						}
					}
				}			
			}			
			else if (command.startsWith("UNDIZ")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String a = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String b = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String c = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				String d = cmdtoken.nextToken();//if (!cmdtoken.hasMoreTokens()) return 0;
				//int amount = getValue(cmdtoken.nextToken(),count,player,target,self);
				
				int player1 = 0;
				int player2 = 0;
				boolean monster = false;
				boolean effect = false;
				
				if (b.startsWith("b")) { player1 = 1; player2 = 2; }
				if (b.startsWith("o")) { player1 = not_player(player); player2= not_player(player); }
				if (b.startsWith("s")) { player1 = player; player2 = player; }
				if (b.endsWith("b")) { monster = true; effect = true; }
				if (b.endsWith("m")) { monster = true; }
				if (b.endsWith("e")) { effect = true; }
				
				for (int i=0;i<5;i++) {
					if (monster) {
						if (player1==1) if (matchcard(a, c,d, m1[i], self, target)) { 
							getSlot(1,i,"m").dizzy = false;
							
						}
						if (player2==2) if (matchcard(a, c,d, m2[i], self, target)) { 
							getSlot(2,i,"m").dizzy = false;
						
						}
					}
					if (effect) {
						if (player1==1) if (matchcard(a, c,d, e1[i], self, target)) { 
							getSlot(1,i,"e").dizzy = false;
							
						}
						if (player2==2) if (matchcard(a, c,d, e2[i], self, target)) { 
							getSlot(2,i,"e").dizzy = false;
						
						}
					}
				}			
			}		
			else if (command.startsWith("LIFEP")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				System.out.println("Amount: " + amount);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) { owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { 
						if (amount > 0 ) p1life+=amount; 
						else {
							if (damage_player(1,-1 * amount) <= 0) 
								endduel(2);	
				
							
						}
					}	
					if (opponent == 2) { 
						if (amount > 0 ) p2life+=amount; 
						else {
							if (damage_player(2,-1 * amount) <= 0) 
								endduel(1);	
				
							
						}
					}						
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { 
						if (amount > 0 ) p1life+=amount; 
						else {
							if (damage_player(1,0-amount) <= 0) 
								endduel(2);	
				
							
						}
					}	
					if (opponent == 2) { 
						if (amount > 0 ) p2life+=amount; 
						else {
							if (damage_player(2,0-amount) <= 0) 
								endduel(1);	
				
							
						}
					}
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { 
						if (amount > 0 ) p1life+=amount; 
						else {
							if (damage_player(1,-1*amount) <= 0) 
								endduel(2);	
				
							
						}
					}	
					if (opponent == 2) { 
						if (amount > 0 ) p2life+=amount; 
						else {
							if (damage_player(2,-1*amount) <= 0) 
								endduel(1);	
				
							
						}
					}
					
				}
					
			}


			else if (command.startsWith("MANAD")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) { owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1D+=amount; }	
					if (opponent == 2) { p2D+=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1D+=amount; }
					if (opponent == 2) { p2D+=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1D+=amount; }
					if (opponent == 2) { p2D+=amount; }	
					
				}
					
			}		
			else if (command.startsWith("MANAG")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) { owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1G+=amount; }	
					if (opponent == 2) { p2G+=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1G+=amount; }
					if (opponent == 2) { p2G+=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1G+=amount; }
					if (opponent == 2) { p2G+=amount; }	
					
				}
					
			}	
			else if (command.startsWith("MANAL")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1L+=amount; }	
					if (opponent == 2) { p2L+=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1L+=amount; }
					if (opponent == 2) { p2L+=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1L+=amount; }
					if (opponent == 2) { p2L+=amount; }	
					
				}
					
			}
			else if (command.startsWith("SMANL")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1L=amount; }	
					if (opponent == 2) { p2L=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1L=amount; }
					if (opponent == 2) { p2L=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1L=amount; }
					if (opponent == 2) { p2L=amount; }	
					
				}
					
			}			
			else if (command.startsWith("SMANG")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true;}
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1G=amount; }	
					if (opponent == 2) { p2G=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1G=amount; }
					if (opponent == 2) { p2G=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1G=amount; }
					if (opponent == 2) { p2G=amount; }	
					
				}
					
			}
			else if (command.startsWith("SMAND")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					if (opponent == 1) { p1D=amount; }	
					if (opponent == 2) { p2D=amount; }
				}
				if (owne) {
					int opponent = player;
					if (opponent == 1) { p1D=amount; }
					if (opponent == 2) { p2D=amount; }	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					if (opponent == 1) { p1D=amount; }
					if (opponent == 2) { p2D=amount; }	
					
				}
					
			}			
 
			else if (command.startsWith("DRAWN")) { // draw more cards
			//	System.out.println("Drawing a card...");
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();
				if (!cmdtoken.hasMoreTokens()) return 0;
				int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
			//	int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				System.out.println("Determining who to do it to...");
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true;}
				for (int x = 0;x<amount;x++) {				
				if (opon) {
					int opponent = not_player(player);
					draw_card(opponent);
				}
				if (owne) {
					int opponent = player;
					draw_card(opponent);	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					draw_card(opponent);
					
				}
				System.out.println("Card Drawn...");
				}
					
			}
			else if (command.startsWith("DRAWC")) {
				System.out.println("Drawing a card...");
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();
			//	int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				System.out.println("Determining who to do it to...");
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) {  owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					draw_card(opponent);
				}
				if (owne) {
					int opponent = player;
					draw_card(opponent);	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					draw_card(opponent);
					
				}
				System.out.println("Card Drawn...");
					
			}
			else if (command.startsWith("DISCA")) {
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String play = cmdtoken.nextToken();//if (!cmdtoken.hasMoreTokens()) return 0;
				//int amount = getvalue(cmdtoken.nextToken(),count,player,target,self);
				boolean opon = false;
				boolean targ = false;
				boolean owne = false;
				
				if (play.equals("opnt")) opon = true;
				if (play.equals("targ")) targ = true;
				if (play.equals("ownr")) owne = true;
				if (play.equals("both")) { owne = true; opon = true; }
				
				if (opon) {
					int opponent = not_player(player);
					int blah;
					if (opponent ==1) blah = waitcards1;
					else blah = waitcards2;
					if (waitcards1 >= numCardsInHand(opponent)) return 0;
					req_discard(opponent);
				}
				if (owne) {
					int opponent = player;
					int blah;
					if (opponent ==1) blah = waitcards1;
					else blah = waitcards2;
					if (waitcards1 >= numCardsInHand(opponent)) return 0;
					req_discard(opponent);	
					
				}				
				if (targ) {
					if (target == null) return 0;
					if (target.isPlayer == false) return 0;
					
					int opponent = target.getPlayer();
					int blah;
					if (opponent ==1) blah = waitcards1;
					else blah = waitcards2;
					if (waitcards1 >= numCardsInHand(opponent)) return 0;
					req_discard(opponent);
					
				}
					
			}
			else if (command.startsWith("RETRN"))  { // Bounce back to hand.
				
				return_to_hand(player,self);					
			}

			else if (command.startsWith("CALLM")) { //All empty spaces are filled with the monster.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				
				int id = Integer.parseInt(cmdtoken.nextToken());
				
			
				for (int i=0;i<5;i++) {
					if ((player==1 && m1[i].dummy)||(player==2 && m2[i].dummy))
						if (create_monster(player,i,id) != 1) return 0;	
						getSlot(player,i,"m").token = true;
				
				}				
					
			}
			else if (command.startsWith("MAKMD")) { //make monster, default stats.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				
				int id = Integer.parseInt(cmdtoken.nextToken());if (!cmdtoken.hasMoreTokens()) return 0;
				String slott = cmdtoken.nextToken();
				int slot;
				if (slott.equals("t")) slot = targetslot;
				else slot = findSlotNumber(self);
				if (create_monster(player,slot,id) != 1) {
					
					
					
					return 0;					
				}
				getSlot(player,slot,"m").token = true;
			}
			else if (command.startsWith("MAKMS")) { //make monster, special stats.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				
				int id = Integer.parseInt(cmdtoken.nextToken());
				if (!cmdtoken.hasMoreTokens()) return 0;
				String slott = cmdtoken.nextToken();
				int slot;
				if (slott.equals("t")) slot = targetslot;
				else slot = findSlotNumber(self);				
				int attack = getvalue(cmdtoken.nextToken(),count,player,target,self);
				if (!cmdtoken.hasMoreTokens()) return 0;
				int lifep = getvalue(cmdtoken.nextToken(),count,player,target,self);
				int returnval = create_monster(player,slot,id,attack,lifep);
				getSlot(player,slot,"m").token = true;
			//	System.out.println("BLAH" + returnval);
				if (returnval != 1) return 0;					
					
			}


			else if (command.startsWith("MAKED")) { //make effect, default stats
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				
				int id = Integer.parseInt(cmdtoken.nextToken());if (!cmdtoken.hasMoreTokens()) return 0;
				String slott = cmdtoken.nextToken();
				int slot;
				if (slott.equals("t")) slot = targetslot;
				else slot = findSlotNumber(self);				
				if (create_effect(player,slot,id) != 1) {
					
				return 0; }
				getSlot(player,slot,"e").token = true;					
					
			}

			else if (command.startsWith("MAKES")) { //make monster, special stats.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				
				int id = Integer.parseInt(cmdtoken.nextToken());if (!cmdtoken.hasMoreTokens()) return 0;
				String slott = cmdtoken.nextToken();
				int slot;
				if (slott.equals("t")) slot = targetslot;
				else slot = findSlotNumber(self);				
				int attack = getvalue(cmdtoken.nextToken(),count,player,target,self);if (!cmdtoken.hasMoreTokens()) return 0;
				int lifep = getvalue(cmdtoken.nextToken(),count,player,target,self);
				if (create_effect(player,slot,id,attack,lifep) != 1) { 
				
				
				return 0;			
				}getSlot(player,slot,"e").token = true;		
					
			}

			else if (command.startsWith("POSSE")) { // possession
				if (!target.isCard) return 0;
				if (target.getCard().dummy) return 0;
				to_graveyard(self);
				self.copydata(target.getCard());
				
				target.getCard().copydata(new CardmasterServerCard());
			
			}
			
			else if (command.startsWith("GRAVE")) { //return cardid to hand.
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();if (!cmdtoken.hasMoreTokens()) return 0;// eat the command
				String cardtype = cmdtoken.nextToken();
				if (! target.isGrave) return 0;
				int cardid = target.s;
				if (! cardtype.equals(carddata[cardid].typecode)) return 0;
				int id = -1;
				if (player == 1) {
					id = deck1.drawGrave(cardid);
						
				}
				if (player == 2) {
					id = deck2.drawGrave(cardid);	
					
				}
				if (id < 10) return 0;
				CardmasterServerCard card = new CardmasterServerCard();
				card.copydata(carddata[id]);
				returntohand = card;
				returntohandplayer = player;
				
				
				
			}			
			else if (command.startsWith("MERGE")) { // Merging
				StringTokenizer cmdtoken = new StringTokenizer(command,"^");	
				if (!cmdtoken.hasMoreTokens()) return 0;
				cmdtoken.nextToken();// eat the command
		
		
		
				if (!cmdtoken.hasMoreTokens()) return 0;
				String findcard = cmdtoken.nextToken();
				
				if (!cmdtoken.hasMoreTokens()) return 0;
				int newcardid = Integer.parseInt(cmdtoken.nextToken());
				
				if (!cmdtoken.hasMoreTokens()) return 0;
				int attack = getvalue(cmdtoken.nextToken(),count,player,target,self);
				
				if (!cmdtoken.hasMoreTokens()) return 0;
				int lifepoints = getvalue(cmdtoken.nextToken(),count,player,target,self);
				if (!target.isCard) return 0;
				if (target.getCard().dummy) return 0;

				
				if (!(target.getCard().name.equals(findcard))) return 0;
				if (owner(target.getCard()) != player) return 0;
				to_graveyard(target.getCard());
				to_graveyard(self);
				self.copydata(carddata[newcardid]);
				self.attack = attack;
				self.lifepoints = lifepoints;
				self.token = true;
			}
		}	
		return 1;
	
	
	}	
	int not_player(int player) {
		if (player == 1) return 2;
		else return 1;	
		
	}
	boolean isAttacking(CardmasterServerCard card) {
		for (int i =0;i<5;i++) {
			System.out.println("Checking attacker " + i);
			if ((m1[i] == card) && (attacker[i+1] >0)) return true;
			if ((m2[i] == card) && (attacker[i+1] >0)) return true;
			
			
		}	
		return false;
	}
	int owner(CardmasterServerCard card){
		for (int i =0;i<5;i++) {
			if (m1[i] == card) return 1;
			if (e1[i] == card) return 1;
			
			
			
			if (m2[i] == card) return 2;
			if (e2[i] == card) return 2;
						
		}
		
		for (int i=0;i<8;i++) {
			if (h1[i] == card) return 1;
			if (h2[i] == card) return 2;
		}
		return 0;	
		
	}
	void resolveattack() {
		for(int i = 1; i<6; i++) {
			if (!(getSlot(playerphase,i-1,"m").dummy))
			if ((!(getSlot(playerphase,i-1,"m").dizzy)))
			if (attacker[i] == 6) { // attack player direclty
				attackresult[10] += getSlot(playerphase,i-1,"m").attack; // save damage to player
				getSlot(playerphase,i-1,"m").dizzy = true;
				if (damage_player(not_player(playerphase),getSlot(playerphase,i-1,"m").attack) <= 0) {
					winner = playerphase;	
				}
			}
			
			else if (attacker[i] > 0 && attacker[i] < 6 && defender[attacker[i]] == i) { //attack some card.
				if (!(getSlot(playerphase,i-1,"m").dummy))
				if ((!(getSlot(playerphase,i-1,"m").dizzy))&&( (!(getSlot(not_player(playerphase),attacker[i]-1,"m").dizzy))||defenderlock[attacker[i]] )) {
					attackresult[attacker[i]-1] = getSlot(playerphase,i-1,"m").attack; // save damage to monster.
					getSlot(playerphase,i-1,"m").dizzy = true;
					int damage = getSlot(not_player(playerphase),attacker[i]-1,"m").attack;
					int spillover = damage_monster(not_player(playerphase),attacker[i]-1,getSlot(playerphase,i-1,"m").attack);
					spillover = (spillover / 2);
					damage_monster(playerphase,i-1,damage);
					attackresult[i-1+5] =damage;
					if (spillover >0 && !defenderlock[attacker[i]]) {
						attackresult[10]+=spillover; //Spillover damage.
						if (damage_player(not_player(playerphase),spillover) <= 0) {
							winner = playerphase;	
						}	
					}			
				}
			}
	
		}
		
		
		
	}
	
	// Go to next phase.
	void goNextPhase() {
		
		phase++;
		
		if (phase == 6) {
			phase = 0;
			if (playerphase == 1) playerphase = 2;
			else if (playerphase == 2) { playerphase = 1; turncount++; }	
			
		}
		System.out.println("Phase " + phase);
		message(STP());	
		
		doPhaseStuff();
	}
	
	
	void doPhaseStuff() {
		message(STC());
		if (phase == PHASE_DRAW) {
			attacking = false;
			for (int i=1;i<6;i++) { attacker[i] = 0; defender[i] = 0; defenderlock[i] = false; }
			for (int i =0;i<11;i++) { attackresult[i] = 0; }
			// mana gain
			if (playerphase == 2 && turncount > 1) {
				p2D++;
				p2G++;
				p2L++;				
			}
			else if (playerphase == 1 && turncount > 1) {
				p1D++;
				p1G++;
				p1L++;				
			}			
			do_end_turn_abilities(not_player(playerphase));
			

			draw_card(playerphase);// draw a card.
			undizzy(playerphase);
			// Do this player's start of turn cleanup abilities
			do_begin_turn_abilities(playerphase);
			message(STN());
			message(STC());
		}
		else if (phase == PHASE_ATTACK) {
			
			attacking = false;
			for (int i=1;i<6;i++) { attacker[i] = 0; defender[i] = 0; defenderlock[i] = false; }
			for (int i =0;i<11;i++) { attackresult[i] = 0; }
		}
		else if ((phase == PHASE_DEFEND)) {
			
				attacking = false;
			for (int i=1;i<6;i++)	if (attacker[i] > 0) attacking = true;
				if( attacking == false) { goNextPhase(); return; } // skip if no attack
				message("ATD#" + playerphase + "#" + attacker[1]+ "#" + attacker[2]+ "#" + attacker[3]+ "#" + attacker[4]+ "#" + attacker[5] + "#");
		}
		else if (phase == PHASE_RESOLVE) {
			if (!attacking) { goNextPhase(); return; } // skip if no attack
			// resolve attack
			attacking = false;
			do_defend_abilities(not_player(playerphase));
			do_attack_abilities(playerphase);
			resolveattack();
			do_after_attack_abilities(playerphase);
			String messagesend = "ATR#" + playerphase + "#";
			for (int i =0;i<11;i++) {
				messagesend = messagesend + attackresult[i] + "#";
			}
			message(messagesend); // send attack result.
			message(STC());
			message(STN());
			if (winner!=0) endduel(winner);
			
			
			
		}

		
		
	}
	
	
	
	void undizzy(int player) {
		if (player ==1) {
			for (int i =0;i<5;i++) {
				if (!m1[i].dummy) m1[i].dizzy = false;
				if (!e1[i].dummy) e1[i].dizzy = false;
			
			}
			
		}
		if (player ==2) {
			for (int i =0;i<5;i++) {
				if (!m2[i].dummy) m2[i].dizzy = false;
				if (!e2[i].dummy) e2[i].dizzy = false;
			
			}
			
		}		
		message(STC());
		
	}
	CardmasterChatRoom() {
	//	System.out.println("Room created.");
		empty = true;
		dead = false;
		name1 = "";
		name2 = "";
		name2wait = "";
		messagebuffer = new String[100];
		messageid = new int[100];
		currentmessageid = 1;
		currentindex = 0;
		loadCardData();
		loadAbilityData();
			
		attacker = new int[6];
		defender = new int[6];
		defenderlock = new boolean[6];
		attackresult = new int[11]; //0-4 are opponent, 5-9 are yours, and 10 is. player.
		}
	public void message(String message) {
		
		currentindex ++;
		if (currentindex >= 100) {
			currentindex = 0;	
			
			
		}
		currentmessageid++;
	//System.out.println("In " + currentindex + " message " + currentmessageid + " : " + message);
		messagebuffer[currentindex] = message;
		messageid[currentindex] = currentmessageid;
	}

	public int messageTag() {
		return currentmessageid;
	}
	public String getMessage(int id) {
		int index;
		index = -1;
	//	System.out.println("Looking for " + id);
		if (id > currentmessageid) return "";
		for (int i = 0;i<100;i++) {
			if (messageid[i] == id) { 
			index = i;
			//	System.out.println("Found message in "+ i);
				}
		}
		if (index == -1) return "";
	//	System.out.println("Returning " + messagebuffer[index]);
		return messagebuffer[index];
	}
	
	public String STN() {
		return ("STN#" + name1 + "#" + p1life + "#" + p1D + "#" + p1L+ "#" + p1G + 
				"#" + name2  + "#" + p2life + "#" + p2D + "#" + p2L  + "#" +  p2G + "#");
		
	}
	
	public String STP() {
		String name = name2;
		if (playerphase == 1)  name = name1; 
		return ("STP"  + "#" +  name  + "#" +  phase  + "#" +  turncount + "#"); 
		
	}
	public String GRA() { // returns the GRAVE string.
		//return "GRA#";
			String gravestring = "GRA#PL1#";
			for (int i =0;i<deck1.gravecards;i++) {
				if (carddata[deck1.grave[i]] != null)
				gravestring = gravestring+carddata[deck1.grave[i]]+"#";
			}
			gravestring = gravestring + "PL2#";	
			for (int i =0;i<deck2.gravecards;i++) {
				if (carddata[deck2.grave[i]] != null)
				gravestring = gravestring+carddata[deck2.grave[i]]+"#";
			}
		
			return gravestring;				
		
	}
	public String STC() {
		if (m1[0]!=null)
		return ("STC#"    +m1[0]+"#"+m1[1]+"#"+m1[2]+"#"+m1[3]+"#"+m1[4]+"#"
						  +e1[0]+"#"+e1[1]+"#"+e1[2]+"#"+e1[3]+"#"+e1[4]+"#"
						  +deck1.deckcards + "#"
						  +h1[0]+"^"+h1[1]+"^"+h1[2]+"^"+h1[3]+"^"+h1[4]+"^"+h1[5]+"^"+h1[6]+"^"+h1[7]+"^"+"#"
						  +m2[0]+"#"+m2[1]+"#"+m2[2]+"#"+m2[3]+"#"+m2[4]+"#"
						  +e2[0]+"#"+e2[1]+"#"+e2[2]+"#"+e2[3]+"#"+e2[4]+"#"
						  +deck2.deckcards + "#"
						  +h2[0]+"^"+h2[1]+"^"+h2[2]+"^"+h2[3]+"^"+h2[4]+"^"+h2[5]+"^"+h2[6]+"^"+h2[7]+"^"
						  +"#"
						  ); 
		else return ("STC#b#b#b#b#b#b#b#b#b#b#0#b#b#b#b#b#b#b#b#b#b#b#b#b#b#b#b#b#b#0#b#b#b#b#b#b#b#b");
		
	}
	
	public String getName() {
		return messagebuffername;	
		
	}
	
	

	//Close Room
	public void close() {
		message("CLO#");
		name1 = "";
		name2 = "";
		name2wait = "";
		dead = true;
		
		
		
	}
	// Chat Message
	public int say(String name, String message) {
	//	System.out.println("Received message from " + name + " : " + message);
	// CHA#" + playerroom.getName() + "#" + outputLine + "#
		message("CHA#" + name + "#" + message + "#");
		
	//	System.out.println("Message Number " + messageid);
		return 1;
	}

	// Opponent Found
	public void opfound(int roomnumber) {
		this.roomnumber =roomnumber;
	try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "games.csc", true); // append
			PrintWriter out = new PrintWriter(writer);
			out.print(System.getProperty("line.separator") + roomnumber + "#" + name1 + "#" + name2 + "#");
	
			out.close();
			writer.close();
		}catch(Exception e){}
		message("OPF#");
		message("MES#Cardmasters Conflict version " + version);
		init_game();
		
	}
	

	
	
	 class AbilityTarget { // data implementing a target
		public boolean isCard = false;
		public boolean isPlayer = false;
		public boolean isGrave = false;
		public int p;
		public int s;
		public String t;
		AbilityTarget(int player, int slot, String type) { // target is a card
			isCard = true;
			p = player;
			s = slot;
			t = type;
			
			
		} 
		AbilityTarget(int player, int cardid) {
			p = player;
			isGrave = true;
			s = cardid;
			
			
		}
		AbilityTarget(int player) { // target is a player
			isPlayer = true;
			p = player;
			
		}
		public CardmasterServerCard getCard() {
			if (!isCard) return null;
			else return getSlot(p,s,t);
			
		}
		
		public int getPlayer() {
			if (!isPlayer) return 0;
			else return p;
			
			
			
		}
		
		
		
		
		
		
		
	}
	
	// victory stuff.
	CardmasterUser[] users;
	

	public void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	
	public boolean userpatch(String name, String command, int amount, String text) {
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "userpatch.csc", true); 
			PrintWriter out = new PrintWriter(writer);
			//out.print(users[1]);
			out.println(name + ":" + command + ":" + text + ":" + amount + ":");
			out.close();
			return true;
	}catch(Exception e) {}
		return false;
	}

	public CardmasterUser loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				CardmasterUser user = users[i];
			//	loadDecks();
				return user;
				
			}
			
			
		}
		return null ;
		
		
	}	
	
	
}