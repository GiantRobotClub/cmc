package webrunner.cardmaster;
/*
 * @(#)CardmasterServer.java 1.0 03/06/29
 *
 * You can modify the template of this file in the
 * directory ..\JCreator\Templates\Template_1\Project_Name.java
 *
 * You can also create your own project template by making a new
 * folder in the directory ..\JCreator\Template\. Use the other
 * templates as examples.
 *
 */

import java.net.*;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;


//		
//			
class CardmasterMatchServer extends Thread{
	
	public boolean breakit = false;


	public void run() {
		System.out.println("Starting Cardmaster Conflict Matchmaker Server...");
		
		
	
		

	

	
		ServerSocket matchSock = null;
		boolean listening = true;
		try {
		//	servSock = new ServerSocket(1234);
			matchSock = new ServerSocket(1240);
		} catch (IOException e) {
			System.err.println("Could not listen on port 1240");
			System.exit(-1);
		}
		int thread = 1;
		CardmasterMatchMaker matchmaker = new CardmasterMatchMaker();
		Timer cleanuptimer;
		cleanuptimer = new Timer();
		cleanuptimer.schedule(new cleanuptimerhandler(matchmaker),0,5000);			
	///	CardmasterChatRoom chatroom = new CardmasterChatRoom(0000,"lobby");
		while (listening) {
			try{new CardmasterMatchmakerThread(matchSock.accept(),matchmaker,thread).start();}
			catch(Exception e) {
			}
		//	new CardmasterServerThread(servSock.accept(),chatroom, thread).start();
			thread++;
			
			if (breakit) break;
		}
		System.out.println("Quitting matchmaker...");
		try{matchSock.close();}catch(Exception e){}
		
	}
	
}
class cleanuptimerhandler extends TimerTask   {
		CardmasterMatchMaker matchmaker;
		CardmasterChatRoom chatroom[];
		 cleanuptimerhandler(CardmasterMatchMaker matchmaker) {
		 	super();
		 	this.matchmaker = matchmaker;
		 	
		 	
		 	
		 }
		 public void run() {
		 	matchmaker.loadUserData();
		 	matchmaker.loadUserPatches();
		 	matchmaker.saveusers();
		 	matchmaker.loadUserData();
		 	
		 }
        
	}






