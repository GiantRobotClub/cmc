package webrunner.cardmaster;
import java.io.*;
import java.util.StringTokenizer;
public class ShowCardDataBean {
		
	
		CardmasterServerCard carddata[];
		public void loadCardData() {
		carddata = new CardmasterServerCard[CardmasterData.NUMBER_OF_CARDS];
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "cards.csc");
			BufferedReader in = new BufferedReader(reader);
			
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
				if (cardid >= 10) carddata[cardid] = new CardmasterServerCard(inputLine);
				
		//	System.out.println(carddata[cardid]);
				
				
			}
			
			
			reader.close();
			
			
		}
		catch (Exception e) {
			e.printStackTrace();}	
		
		
	}	
	public String getCardName(int i) {
	//	System.out.println("Getting" + i);
		int cardid = i;
		if (!carddata[cardid].dummy) return (carddata[cardid].name);
		else return ("Dummy Card");
		
		
	}
	
	public String getImage(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy) return ("cardpics/" + carddata[cardid].picture);	
		else return ("x");
		
	}
	
	public String getManaCost(int i) {
		int cardid = i;
			if (!carddata[cardid].dummy) 
				return (carddata[cardid].Dcost) + "D " 
				+ (carddata[cardid].Lcost) + "L " 
				+ (carddata[cardid].Gcost) + "G ";
		else return("0D 0L 0G");	
	}
	public String getSacWorth(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy)
			if (!carddata[cardid].typecode.equals("s"))
				return "Sacrifice for: " + (carddata[cardid].Dsac) + "D " 
				+ (carddata[cardid].Lsac) + "L " 
				+ (carddata[cardid].Gsac) + "G ";	
		
		return("");
	}
	public String getCardTypeString(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].typecode.equals("s"))	return "cast spell";
			else if (carddata[cardid].typecode.equals("m") && carddata[cardid].unique) 
				return "summon unique " + carddata[cardid].mtype;
			else if (carddata[cardid].typecode.equals("m")) return "summon " + carddata[cardid].mtype;
			else if (carddata[cardid].typecode.equals("e")) return "create effect";
						
			
			
			
		}
		return "";
	}
	
	public String getAttackLifepoints(int i) {
		int cardid =i;
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].typecode.equals("m"))	return carddata[cardid].attack + "/" + carddata[cardid].lifepoints;			
		}
		return "";
	}	
	public String getBackColor(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].colorcode == 2) return "black";
			if (carddata[cardid].colorcode == 4) return "white";
			if (carddata[cardid].colorcode == 8) return "#D4D4D4";

		}	
		
		return "#C4C4C4";
	}	
	public String getTextColor(int i) {	int cardid = i;
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].colorcode == 2) return "orange";
			if (carddata[cardid].colorcode == 4) return "black";
			if (carddata[cardid].colorcode == 8) return "#444444";
				
				
				
		}	
		
		return "black";
	}
	public String getCardText(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy) {
			StringTokenizer tokenizer = new StringTokenizer(carddata[cardid].cardtext,"$");
			String cardtext = tokenizer.nextToken();
			while (tokenizer.hasMoreTokens()) {
				cardtext = cardtext + "<br>" + tokenizer.nextToken();	
				
			}
			return cardtext;
			
		}
		return "";
	}
	
	public String getRarity(int i) {
		int cardid = i;
		if (!carddata[cardid].dummy) {
			int commonness = carddata[cardid].printed;
			int rarity = 101 - commonness;
			return "" + rarity;			
			
			
		}
		return "";
		
	}
	
	
	
	
	
	
	
}