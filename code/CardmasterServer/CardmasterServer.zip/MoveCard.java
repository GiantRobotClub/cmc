package webrunner.cardmaster;
import java.io.*;
public class MoveCard {
	CardmasterUser[] users;
	CardmasterUser user;
	
	// move card from deck1, to deck2.
	public boolean moveCard(int deck1, int deck2, String name, int card) {
		loadUserData();
		if (!loadUser(name)) return false;
		if ((!(user.hasDeck(deck1)) )||( !(user.hasDeck(deck2)))) return false;
		
		CardmasterLibrary deckone = new CardmasterLibrary(deck1);
		CardmasterLibrary decktwo = new CardmasterLibrary(deck2);
		if (deckone.numcards == 1) return false; //cant move last card.
		if (!(deckone.hasCard(card))) return false;
		if (!(deckone.takeCard(card))) return false;
		decktwo.addCard(card);
		
		try{
		
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck1 + ".csc");
		PrintWriter out = new PrintWriter(writer);
		for(int i =0;i<deckone.numcards;i++) {
			if (i < deckone.numcards-1) out.println(deckone.cards[i]);	
			else out.print(deckone.cards[i]);
			
			
		}
		
		
		out.close();

		 writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck2 + ".csc");
	 out = new PrintWriter(writer);
		for(int i =0;i<decktwo.numcards;i++) {
			if (i < decktwo.numcards-1) out.println(decktwo.cards[i]);	
			else out.print(decktwo.cards[i]);
			
			
		}
		
		
		out.close();
		
		return true;	
		}catch(Exception e) {
		e.printStackTrace();
		System.out.println("******EXCEPTION*********");
		return false; }
		
		
	}
	
	
	
	
	public	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
/*	public boolean userpatch(String name, String command, int amount, String text) {
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "userpatch.csc", true); 
			PrintWriter out = new PrintWriter(writer);
			//out.print(users[1]);
			out.println(name + ":" + command + ":" + text + ":" + amount + ":");
			out.close();
			return true;
	}catch(Exception e) {}
		return false;
	}*/
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}	
}