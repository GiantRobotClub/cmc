package webrunner.cardmaster;

import java.io.*;
import java.util.Timer;
import java.util.TimerTask;
public class CMCserver {
	
	
	
	public static void main(String args[])  {
		CardmasterServer serverThread = new CardmasterServer();
		CardmasterMatchServer matchThread = new CardmasterMatchServer();
		serverThread.start();
		matchThread.start();
		Timer cleanuptimer;
		cleanuptimer = new Timer();
		cleanuptimer.schedule(new quitterhandler(serverThread,matchThread),0,500);		
		
	}
	

}




class quitterhandler extends TimerTask   {
	
	CardmasterServer	serverThread;
	CardmasterMatchServer matchThread;
		public quitterhandler(CardmasterServer serverThread, CardmasterMatchServer matchThread) {
			super();
			this.serverThread = serverThread;
			this.matchThread = matchThread;	
			
			
		}
		 public void run() {
			File file = new File(CardmasterData.DIRECTORY + "quit");
			if (file.exists()) {
				System.out.println("Quitting");
				serverThread.breakit = true;
				matchThread.breakit = true;
				cancel();
			}

		 }
        
	}



