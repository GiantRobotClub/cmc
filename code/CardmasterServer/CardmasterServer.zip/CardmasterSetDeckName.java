package webrunner.cardmaster;
import java.io.*;

public class CardmasterSetDeckName {
	

	public String name;
	CardmasterUser[] users;
	CardmasterUser user;
	
	public	boolean loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
			
	in.close();	 	return true;}catch(Exception e){return false;}
	}
	
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}
		


	
	public boolean setDeckName(int deck, String deckName) {
		if (!loadUserData()) return false;
		if (!loadUser(name)) return false;
		if (!user.hasDeck(deck)) return false;
		try {
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deckname_" + deck + ".csc");
			PrintWriter out = new PrintWriter(writer);
			out.println(deckName);
			out.close();
			writer.close();
			return true;
			
			
		}
		catch (Exception e) {
			return false;	
			
		}
		
		
		
		
	}
	
	
	
}