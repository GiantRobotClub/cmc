package cmcbeans;
import java.io.*;
import java.util.StringTokenizer;
public class CardmasterCharacterCreate {
	private String name;
	private String password;
	
	
	public void setName(String value) {
		name = value;	
		
	}
	
	
	public boolean moreCards() {
		
		 return true;	
	}
}

