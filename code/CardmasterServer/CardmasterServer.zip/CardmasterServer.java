package webrunner.cardmaster;
/*
 * @(#)CardmasterServer.java 1.0 03/06/29
 *
 * You can modify the template of this file in the
 * directory ..\JCreator\Templates\Template_1\Project_Name.java
 *
 * You can also create your own project template by making a new
 * folder in the directory ..\JCreator\Template\. Use the other
 * templates as examples.
 *
 */

import java.net.*;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;


//		
//			
class CardmasterServer extends Thread{
	

   boolean breakit = false;

	public void run()  {
		System.out.println("Starting Cardmaster Conflict Java Server...");
		
		
	
		

		CardmasterChatRoom chatroom[];

		chatroom = new CardmasterChatRoom[500];
		for (int i=0;i<500;i++) {
			chatroom[i] = new CardmasterChatRoom();
		}
		Timer cleanuptimer;
		cleanuptimer = new Timer();
		cleanuptimer.schedule(new matchtimerhandler(chatroom),0,500);	
		ServerSocket servSock = null;
		//ServerSocket matchSock = null;
		boolean listening = true;
		try {
			servSock = new ServerSocket(1234);
			//matchSock = new ServerSocket(1240);
		} catch (IOException e) {
			System.err.println("Could not listen on port 1234");
			System.exit(-1);
		}
		int thread = 1;
	//	CardmasterMatchMaker matchmaker = new CardmasterMatchMaker();
	///	CardmasterChatRoom chatroom = new CardmasterChatRoom(0000,"lobby");
		while (listening) {
		//	Socket socket = matchSock.accept;
		//	if (socket != 
		//	new CardmasterMatchmakerThread(matchSock.accept,matchmaker,thread).start();
			try{new CardmasterServerThread(servSock.accept(),chatroom, thread).start();}
			catch (Exception e) {
				System.out.println("Couldn't accept connection");	
				
			}
			thread++;
			if (breakit) break;
			
		}
		System.out.println("Quitting game server..");
		try{servSock.close();} catch (Exception e){}
		
	}
}

/*
 * cleanuptimerhandler
 * Goes through all the rooms regularly cleaning up the dead ones.
 */
class matchtimerhandler extends TimerTask   {
	
		CardmasterChatRoom chatroom[];
		 matchtimerhandler(CardmasterChatRoom chatroom[]) {
		 	super();
		 	this.chatroom = chatroom;
		 	
		 	
		 	
		 }
		 public void run() {
		 	for (int i=0;i<500;i++) {
		 		if (chatroom[i].dead) {
		 			chatroom[i] = null;
		 			chatroom[i] = new CardmasterChatRoom();	
		 			
		 		}		
		 		
		 	}
		 	
		 }
        
	}

