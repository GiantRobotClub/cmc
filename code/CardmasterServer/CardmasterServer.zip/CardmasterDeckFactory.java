package webrunner.cardmaster;
import java.io.*;
import java.util.Random;
import java.util.StringTokenizer;
public class CardmasterDeckFactory {
	

	CardmasterServerCard carddata[];
	
	public void init() {
		loadCardData();	
		createCirculation();
		
	}
	
	public void addToCirculation(int i) {
		int[] temp = new int[circulation.length+1];
		System.arraycopy(circulation,0,temp,0,circulation.length);
		temp[circulation.length] = i;
		circulation = new int[temp.length];
		System.arraycopy(temp,0,circulation,0,temp.length);
		
	}
	public void createCirculation() {
		circulation = new int[1];
		circulation[0] = -1;
		for (int i =10;i<CardmasterData.NUMBER_OF_CARDS;i++) {
			if (!(carddata[i]==null)) {
			//	System.out.println("Doing circulation for card " + i);
				int cardamount = carddata[i].printed;
				cardamount = cardamount + (int)((double)((double)cardamount / 100.0) * cardamount);
				for (int j = 0;j<cardamount;j++)
					addToCirculation(i);
					
			
			}	
			
		}	
		
		
	}
	
	public int[] circulation;
	
	void loadCardData() {
		carddata = new CardmasterServerCard[CardmasterData.NUMBER_OF_CARDS];
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "cards.csc");
			BufferedReader in = new BufferedReader(reader);
			
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
				if (cardid >= 10) carddata[cardid] = new CardmasterServerCard(inputLine);
				
			//System.out.println(carddata[cardid]);
				
				
			}
			
			
			reader.close();
			
			
		}
		catch (Exception e) {
			e.printStackTrace();}	
		
		
	}
	public int createNewDeck(int colorcode,int numcards) {
		
		return createNewDeck(colorcode,numcards,-1);	
	}
	public int createNewDeck(int colorcode, int numcards, int expan) {
	//	System.out.println("CODE: " + colorcode);
		try{
		int decknumber = getClearDeckCode();
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + decknumber + ".csc");
		PrintWriter out = new PrintWriter(writer);
		Random random = new Random();
		
		for (int i = 0; i <numcards; i++) {
			
			int card = -1; int rand = -1;	
			while (card == -1) {
				rand = random.nextInt(circulation.length);
				card = circulation[rand];
			//	System.out.println(card);
				if (card != -1) {	
					if (((colorcode != 0) && (carddata[card].colorcode != colorcode))
					||(!(carddata[card].available)) || ((expan != -1) && (carddata[card].expansioncode != expan))) card = -1;
					
				}
			//	System.out.println(colorcode " - " + card);
			}
			
			circulation[rand] = -1;
			
			if (i < numcards-1) out.println(card);	
			else out.print(card);
			
			
		}
		out.close();
		
		return decknumber;	
		}catch(Exception e) {
		e.printStackTrace();
		System.out.println("******EXCEPTION*********");
		return -1; }
	}	
	int getClearDeckCode() {
		Random random = new Random();
		int number = 1;
		while (((new File(CardmasterData.DIRECTORY + "decks/deck_" + number + ".csc")).exists())) {
			number= random.nextInt(9000);

		}
		
		return number;
		
		
	}
	
	
	

	
	
	
	
	
}