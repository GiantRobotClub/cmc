package webrunner.cardmaster;
import java.io.*;
import java.util.StringTokenizer;
public class CardmasterMatchMaker{
	private String[] messageto;
	private String[] messagebuffer;
	private int[] messageid;
	public int currentmessageid;
	public int currentindex;
	
	public CardmasterUser[] users;
	public String[] player;
	public String[] challenges;
	
	
	public String[] obstuff;

	
	CardmasterMatchMaker() {
		messagebuffer = new String[100];
		messageid = new int[100];
		messageto = new String[100];
		currentmessageid = 1;
		currentindex = 0;
		player = new String[0];
		challenges = new String[0];
			
		loadUserData();
	
	
	}
	public String playlist() {
		String playlist = "";
		for (int i=0;i<player.length;i++) {
			playlist = playlist + player[i] + "#" + loadUser(player[i]).wins + "#" + loadUser(player[i]).losses + "#";			
		}
		return playlist;
		
	}
	public void quit (String name) {
		for (int i =0; i<player.length; i++) {
			if (player[i].equals(name)) {
				player[i] = player[player.length - 1];
				challenges[i] = challenges[player.length -1];
				String[] temps = new String[player.length -1];
				String[] tempc = new String[player.length -1];
				System.arraycopy(player,0,temps,0,player.length-1);
				System.arraycopy(challenges,0,tempc,0,player.length-1);
				player = new String[temps.length];
				challenges = new String[temps.length];
								
				System.arraycopy(temps,0,player,0,player.length);
				System.arraycopy(tempc,0,challenges,0,player.length);
				message("PLAYLIST#" + playlist(),"$all$");
				message("CHASTAT#" + name + " has quit..", "$all$");
				
				
				
				
				
				return;
			} 	
		
		}

		
	}	
	
	public boolean login (String name) {
		System.out.println("Attempting join " + name);
		for (int i=0; i<player.length; i++) { 
			if (player[i].equals(name))  {
				return false;
			}
		}
				String[] temps = new String[player.length +1];
				String[] tempc = new String[player.length +1];
				System.arraycopy(player,0,temps,0,player.length);
				System.arraycopy(challenges,0,tempc,0,player.length);
				player = new String[temps.length];
				challenges = new String[temps.length];
								
				System.arraycopy(temps,0,player,0,player.length);
				System.arraycopy(tempc,0,challenges,0,player.length);
		player[player.length-1] = name;
		message("PLAYLIST#" + playlist(), "$all$");
		message("CHASTAT#" + name + " has joined..","$all$");
		return true;	
	}
	
	public boolean challenge (String name, String toname) {
		int playerno = -1;
		for (int i=0;i<player.length;i++) {
			if (name.equals(player[i])) { 
				playerno = i;
			
			}	
			
			
		}
		if (playerno == -1) return false;
		if (challenges[playerno] != null) {
			unchallenge(name,challenges[playerno]); // cancel player's previous challenge.
				
				
		}
		
		int player2no = -1;
		for (int i=0;i<player.length;i++) {
			if (toname.equals(player[i])) { 
				player2no = i;
			
			}	
			
			
		}		
		if (player2no == -1) return false;
		
		challenges[playerno] = toname;
		message("CHALFROM#" + name + "#",toname);
		if (! (challenges[player2no] == null))
	 	if (challenges[player2no].equals(name)) match(name,toname); 
		return true;	
	}
	
	void match(String name, String toname) {
		message("MATCHMADE#" + toname + "#",name);
		message("MATCHMADE#" + name + "#",toname);
		message("CHASTAT#Playing against: " + name + "#",toname);
		message("CHASTAT#Playing against: " + toname + "#",name);
		 
		quit(name);
		quit(toname);	
		message("CHASTAT#" + name + " and " + toname + " are playing Cardmaster Conflict!#","$all$");

	}
	public boolean unchallenge (String name, String toname) {
		int playerno = -1;
		for (int i=0;i<player.length;i++) {
			if (name.equals(player[i])) { 
				playerno = i;
			
			}	
			
			
		}
		if (playerno == -1) return false;
		if (challenges[playerno] == null) return false;
		if (!(challenges[playerno].equals(toname))) return false;
		message("UNCHALFR#" + challenges[playerno] + "#",name);
		challenges[playerno] = null;
		
		return true;	
	}
	
	public void message(String message, String name) {
		System.out.println(message);
		
		currentindex ++;
		if (currentindex >= 100) {
			currentindex = 0;	
			
			
		}
		currentmessageid++;
	//System.out.println("In " + currentindex + " message " + currentmessageid + " : " + message);
		messagebuffer[currentindex] = message;
		messageid[currentindex] = currentmessageid;
		messageto[currentindex] = name;
	}

	public int messageTag() {
		return currentmessageid;
	}	
	
	public String getMessage(int id) {
		int index;
		index = -1;
	//	System.out.println("Looking for " + id);
		if (id > currentmessageid) return "";
		for (int i = 0;i<100;i++) {
			if (messageid[i] == id) { 
			index = i;
			//	System.out.println("Found message in "+ i);
				}
		}
		if (index == -1) return "";
	//	System.out.println("Returning " + messagebuffer[index]);
		return messagebuffer[index];
	}
	
	public void remove_game(String name) {
		try{
		File file = new File(CardmasterData.DIRECTORY + "games.csc");
		if (!(file.exists())) return;
		FileReader reader = new FileReader(	CardmasterData.DIRECTORY + "games.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		String[] lines = new String[0];
		while (((inputLine = in.readLine()) != null)) {
			if (inputLine.indexOf(name) > -1) continue;
			String[] temp = new String[lines.length];
			System.arraycopy(lines,0,temp,0,lines.length);
			lines = new String[lines.length+1];
			System.arraycopy(temp,0,lines,0,temp.length);
			lines[lines.length-1] = inputLine;
			
		}
		in.close();
		reader.close();
		
		FileWriter writer = new FileWriter( CardmasterData.DIRECTORY + "games.csc");
		PrintWriter out = new PrintWriter(writer);
		for (int i=0;i<lines.length;i++) {
			out.println(lines[i]);	
			
		}
		out.close();
		writer.close();
			
			
		
		
			
		} catch(Exception e) {
		
		}
	}
	public String getToName(int id) {
		int index;
		index = -1;
	//	System.out.println("Looking for name " + id);
		if (id > currentmessageid) return "";
		for (int i = 0;i<100;i++) {
			if (messageid[i] == id) { 
			index = i;
			//	System.out.println("Found name in "+ i);
				}
		}
		if (index == -1) return "";
	//	System.out.println("Returning name " + messageto[index]);
		return messageto[index];
	}	

	public void loadUserPatches() {
	try{ 
	File file = new File(CardmasterData.DIRECTORY + "userpatch.csc");
	if (!(file.exists())) return;
	FileReader reader = new FileReader(CardmasterData.DIRECTORY + "userpatch.csc");
	BufferedReader in = new BufferedReader(reader);
	String inputLine;
	while (((inputLine = in.readLine()) != null)) {
		StringTokenizer tokenizer = new StringTokenizer(inputLine,":");
		if (!(tokenizer.hasMoreTokens())) continue;
		String name = tokenizer.nextToken();
		System.out.println(name);
		String command = tokenizer.nextToken();
		String text = tokenizer.nextToken();
		int amount = Integer.parseInt(tokenizer.nextToken());
		CardmasterUser user = loadUser(name);
		if (command.equals("addd")) {
			
			System.out.println("Adding deck " + amount + " for " + user.name);
			user.addDeck(amount);	
		}
		else if (command.equals("setp")) {
			System.out.println("Setting user " + user.name + " primary deck to " + amount);
			user.setPrimaryDeck(amount);
		}	
		else if (command.equals("addw")) {
			System.out.println("Adding win for " + user.name);
			user.wins++;
			remove_game(user.name);
		}
		else if (command.equals("addl")) {
			System.out.println("Adding loss for " + user.name);
			user.losses++;
		}
		else if (command.equals("remd")) {
			System.out.println("Removing deck " + amount + " for " + user.name);
			
			user.removeDeck(amount);
			
		}
		else if (command.equals("addp")) {
			
			System.out.println("Adding points " + amount + " for " + user.name);
			user.points += amount;
		}
		else if (command.equals("remp")) {
			
			System.out.println("Taking Points " + amount + " for " + user.name);
			user.points -= amount;
		}	
		
	}
	
	reader.close();
	in.close();file.delete();
//	saveusers();
	
	
	}catch(Exception e) {
		e.printStackTrace();
		return;
	}
}

	public CardmasterUser loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				CardmasterUser user = users[i];
			//	loadDecks();
				return user;
				
			}
			
			
		}
		return null ;
		
		
	}
public void makeBackup() {
	try {
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "backupusers.csc");
		PrintWriter out = new PrintWriter(writer);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			out.println(inputLine);	
		}
		out.close();
		in.close();
		reader.close();
		writer.close();
		
		
	}
	catch (Exception e) {}
	
	
}		
public void restoreBackup() {
	try {
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "backupusers.csc");
		BufferedReader in = new BufferedReader(reader);
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "users.csc");
		PrintWriter out = new PrintWriter(writer);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			out.println(inputLine);	
		}
		out.close();
		in.close();
		reader.close();
		writer.close();
		
		
	}
	catch (Exception e) {}
	
	
}
public void loadUserData() {
		try{
		users = new CardmasterUser[1];
		File file = new File(CardmasterData.DIRECTORY + "users.csc");
		if (!(file.length() > 1)) restoreBackup();
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;

				
		
		
			while (((inputLine = in.readLine()) != null)) {
				CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
				System.arraycopy(users,0,tempusers,0,users.length);
			//	System.out.println("Line " + inputLine);
				tempusers[users.length] = new CardmasterUser(inputLine);
				users = new CardmasterUser[tempusers.length];
				System.arraycopy(tempusers,0,users,0,tempusers.length);
	
			}
		
	in.close();	 	}catch(Exception e){}
	}	


	public boolean saveusers() {
		makeBackup();
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "users.csc"); 
			PrintWriter out = new PrintWriter(writer);
			out.print(users[1]);
			for (int i =2;i<users.length;i++) {
				out.print(System.getProperty("line.separator") + users[i]);
				
				
			}
			out.close();
			return true;
			
	}catch(Exception e) {}
		return false;
	}


}
	