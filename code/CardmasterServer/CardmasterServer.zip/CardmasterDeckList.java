package webrunner.cardmaster;
import java.io.*;

public class CardmasterDeckList {
	CardmasterUser[] users;
	CardmasterUser user;
	int numdecks;
	
	public	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}
	
	
	
	public int numDecks() {
		return user.decks.length;
		
		
	}
	public int getDeck(int i) {
		return user.decks[i];	
		
		
	}
	public String getDeckName(int deck) {
		File file = new File(	CardmasterData.DIRECTORY + "decks/deckname_" + deck + ".csc");
		if (! file.exists() ) return "Generic Deck";
		else {
			try {
				FileReader reader = new FileReader(file);
				BufferedReader in = new BufferedReader(reader);
				String deckname =  in.readLine();
				reader.close();
				in.close();
				return deckname;
				
				
			}catch(Exception e) {
				
			return "Generic Deck";	
				
			}	
			
			
		}
	}
	
	public String primaryDeckMarker(int i) {
		if (user.decks[i] == user.primarydeck) return "(Primary)";
		else return "";
		
		
	}
	
	
	
	
	
}