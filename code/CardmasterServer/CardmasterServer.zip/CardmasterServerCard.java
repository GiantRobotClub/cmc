package webrunner.cardmaster;
import java.util.StringTokenizer;
public class CardmasterServerCard  {
	public int attack;
	public int lifepoints; // used as two extra slots for Effect cards+ "." + 
	public int Dcost;
	public int Lcost;
	public int Gcost;
	public int Dsac;
	public int Lsac;
	public int Gsac;
	public int colorcode; // 2D, 4L, 8G add for code
	public int cardid;
	public int expansioncode; 
	public int printed;
	public int accountedfor;
	public boolean available;
	public boolean ability; // has an ability
	public boolean targete; // ability targets Effects
	public boolean targetp; // ability targets Players
	public boolean targetm; // ability targets monsters
	public boolean targets; // Ability targets slots
	public boolean targeta; // Ability automatically targets (no target specification required)
	public boolean targetg;
	public boolean unique; // can play only one
	public boolean dizzy; // is dizzy
	public boolean token = false;
	public String mtype; // monster type code+ "." + 
	public String name;
	public String cardtext;
	public String picture;
	public String typecode; // e, m, or s+ "." + 
	public String targetmtype; // ability or spell target monster type if applicable+ "." + 
	public boolean dummy;
 	public String urlcodebase;
	public int healfor = 0;
	
	// Constructor with TEXT STRING
	
	public int bToI(boolean bool) {
		if (bool) return 1;
		else return 0;	
	}
	
	public String toString() {
		if (dummy) return "b";
		if (typecode == null)  {
			dummy = true;
			return "b";
		}
		
		String returnstring = cardid + "." + typecode + "." + name+ "." + Dcost+ "." + Lcost+ "." + Gcost+
		 "." + colorcode+ "." + picture + "." + expansioncode + "." + cardtext + "." + 
		 bToI(targete)+ "." + bToI(targetp)+ "." + bToI(targets)+ "." + bToI(targetm)+ "." + bToI(targeta)+ "." + bToI(targetg)+
		  "." + targetmtype + ".";
		  
		 if (typecode.equals("e") || typecode.equals("m")) {
		 	returnstring = returnstring + bToI(ability)+ "." + Dsac+ "." + Lsac+ "." +Gsac+ "." + 
		 	bToI(unique)+ "." + bToI(dizzy)+ "." + attack+ "." + lifepoints + ".";
		 	if (typecode.equals("m")) returnstring = returnstring + mtype + ".";
		 	
		 	
		 }
	
		return returnstring;
		
		
	}
	CardmasterServerCard(String datastring) {
		StringTokenizer tokenizer = new StringTokenizer(datastring, "#");
		cardid = Integer.parseInt(tokenizer.nextToken());
		name = tokenizer.nextToken();
		typecode = tokenizer.nextToken();
		Dcost = Integer.parseInt(tokenizer.nextToken());
		Lcost = Integer.parseInt(tokenizer.nextToken());
		Gcost = Integer.parseInt(tokenizer.nextToken());
		colorcode = Integer.parseInt(tokenizer.nextToken());			
		picture = tokenizer.nextToken();
		expansioncode = Integer.parseInt(tokenizer.nextToken());
		cardtext = tokenizer.nextToken();
		printed = Integer.parseInt(tokenizer.nextToken());
		available = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		targete = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		targetp = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		targets = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		targetm = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		targeta = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
		//System.out.println(cardid);
		targetg = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false; 
		targetmtype = tokenizer.nextToken();
		if (typecode.equals("m") || typecode.equals("e")) {
			ability = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
			Dsac = Integer.parseInt(tokenizer.nextToken());
			Lsac = Integer.parseInt(tokenizer.nextToken());
			Gsac = Integer.parseInt(tokenizer.nextToken());
			unique = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
			dizzy = (Integer.parseInt(tokenizer.nextToken()) == 1) ? true : false;
			attack = Integer.parseInt(tokenizer.nextToken());
			lifepoints = Integer.parseInt(tokenizer.nextToken());
			if (typecode.equals("m")) mtype = tokenizer.nextToken();
			
			
		}
		accountedfor = 0;
		
		
		
		
		
		
		
	}
	// Constructor for MONSTERS
	CardmasterServerCard(String name, String cardtext, String picture, String typecode, String targetmtype,
		 boolean targete, boolean targetp, boolean targetm, boolean targets, boolean targeta,
		 int cardid, int expansioncode, int colorcode, int Dcost, int Lcost, int Gcost,
		 int Dsac, int Lsac, int Gsac, boolean unique, boolean ability, int attack, int lifepoints, String mtype){	

	//	System.out.println(image);
		typecode = "m";
		this.name = name;
		this.cardtext = cardtext;
		this.picture = picture;
		this.typecode = typecode;
		this.cardtext = cardtext;
		this.targetmtype = targetmtype;
		this.targete = targete;
		this.targetp = targetp;
		this.targetm = targetm;
		this.targets = targets;
		this.targeta = targeta;
		this.cardid = cardid;
		this.expansioncode = expansioncode;
		this.colorcode = colorcode;
		this.Dcost = Dcost;
		this.Lcost = Lcost;
		this.Gcost = Gcost;
		this.Dsac = Dsac;
		this.Lsac = Lsac;
		this.Gsac = Gsac;
		this.unique = unique;
		this.ability = ability;
		this.attack = attack;
		this.lifepoints = lifepoints;
		this.mtype = mtype;
		targetg = false;
	//	System.out.println(this.image);

	
	}
	// Constructor for EFFECTS
	CardmasterServerCard(String name, String cardtext, String picture, String typecode,String targetmtype,
		 boolean targete, boolean targetp, boolean targetm, boolean targets, boolean targeta,
		 int cardid, int expansioncode, int colorcode, int Dcost, int Lcost, int Gcost,
		 int Dsac, int Lsac, int Gsac, boolean unique, boolean ability, int attack, int lifepoints){	
	
	
			
		typecode = "e";
		this.name = name;
		this.cardtext = cardtext;
		this.picture = picture;
	//	System.out.println(image);
	//	System.out.println(this.image);
		this.typecode = typecode;
		this.cardtext = cardtext;
		this.targetmtype = targetmtype;
		this.targete = targete;
		this.targetp = targetp;
		this.targetm = targetm;
		this.targets = targets;
		this.targeta = targeta;
		this.cardid = cardid;
		this.expansioncode = expansioncode;
		this.colorcode = colorcode;
		this.Dcost = Dcost;
		this.Lcost = Lcost;
		this.Gcost = Gcost;
		this.Dsac = Dsac;
		this.Lsac = Lsac;
		this.Gsac = Gsac;
		this.unique = unique;
		this.ability = ability;
		this.attack = attack;
		this.lifepoints = lifepoints;
		targetg = false;
	
	}
	// Constructor for MAGIC
	void setDizzy(boolean dizzy)
	{ this.dizzy = dizzy; }
	CardmasterServerCard(String name, String cardtext, String picture, String typecode, String targetmtype,
		 boolean targete, boolean targetp, boolean targetm, boolean targets, boolean targeta,
		 int cardid, int expansioncode, int colorcode, int Dcost, int Lcost, int Gcost){	
	
	
			
		typecode = "s";
		this.name = name;
		this.cardtext = cardtext;
		this.picture = picture;
		this.typecode = typecode;
		this.cardtext = cardtext;
		this.targetmtype = targetmtype;
		this.targete = targete;
		this.targetp = targetp;
		this.targetm = targetm;
		this.targets = targets;
		this.targeta = targeta;
		this.cardid = cardid;
		this.expansioncode = expansioncode;
		this.colorcode = colorcode;
		this.Dcost = Dcost;
		this.Lcost = Lcost;
		this.Gcost = Gcost;
		this.Dsac = Dsac;
		this.Lsac = Lsac;
		this.Gsac = Gsac;
		targetg = false;
}

	CardmasterServerCard() {
		dummy = true;
	}
	
	void copydata(CardmasterServerCard card) {
	//	System.out.println("copy..");
			//	System.out.println(card.image);
				if (card == null) return;
				this.name = card.name;
				this.cardtext = card.cardtext;
				this.picture = card.picture;
				//System.out.println(this.image);
				this.typecode = card.typecode;
				this.cardtext = card.cardtext;
				this.targetmtype = card.targetmtype;
				this.targete = card.targete;
				this.targetp = card.targetp;
				this.targetm = card.targetm;
				this.targets = card.targets;
				this.targeta = card.targeta;
				this.cardid = card.cardid;
				this.expansioncode = card.expansioncode;
				this.colorcode = card.colorcode;
				this.Dcost = card.Dcost;
				this.Lcost = card.Lcost;
				this.Gcost = card.Gcost;
				this.Dsac = card.Dsac;
				this.Lsac = card.Lsac;
				this.Gsac = card.Gsac;
				this.targetg = card.targetg;
			this.dummy = card.dummy;
			this.dizzy = card.dizzy;
			
				this.Dsac = card.Dsac;
				this.Lsac = card.Lsac;
				this.Gsac = card.Gsac;
				this.unique = card.unique;
				this.ability = card.ability;
				this.attack = card.attack;
				this.lifepoints = card.lifepoints;
				this.mtype = card.mtype;
				this.healfor = 0;
				this.token = card.token;
		
	}


		
}	
