package webrunner.cardmaster;
import java.io.*;
//import java.util.StringTokenizer;
import java.util.Random;
// Card library/deck
public class CardmasterUserData {
	
	CardmasterUser[] users;
	public CardmasterUser user;

	public void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	
	public boolean userpatch(String name, String command, int amount, String text) {
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "userpatch.csc", true); 
			PrintWriter out = new PrintWriter(writer);
			//out.print(users[1]);
			out.println(name + ":" + command + ":" + text + ":" + amount + ":");
			out.close();
			return true;
	}catch(Exception e) {}
		return false;
	}
	
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}

}