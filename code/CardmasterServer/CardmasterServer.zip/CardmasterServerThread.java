package webrunner.cardmaster;
import java.net.*;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.StringTokenizer;

import java.awt.event.*; 
public class CardmasterServerThread extends Thread {
   int messagetag = 1;
   int threadnum;
   boolean pingreply;
   Timer timer;
   Timer pingtimer;

   String inputLine = "";
   private Socket socket = null;
   CardmasterChatRoom chatroom[];
   CardmasterChatRoom playerroom;
   boolean observer = false;
   PrintWriter out;
   BufferedReader in;
   String name;
   public int roomnumber;
   public CardmasterServerThread(Socket socket, CardmasterChatRoom chatroom[], int threadnum) {
   		super("CardmasterServerThread");
   		this.chatroom = chatroom;
		this.socket = socket;
		this.threadnum = threadnum;
		System.out.println("Thread " +  threadnum + " created.");
   }   	
   	
   public void run() {
   	pingreply = true;
   try {
	     out = new PrintWriter(socket.getOutputStream(), true);
	     in = new BufferedReader(
				    new InputStreamReader(
				    socket.getInputStream()));
	

			timer = new Timer();
			timer.schedule(new threadtimer(),0,200);
			pingtimer = new Timer();
			pingtimer.schedule(new timerping(),0,50000);
			
		//	if (inputLine.equals("quit the game")) break;
			
			
			
			
	    
//	    out.close();
//	    in.close();
//	    socket.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
   	
   	
 	CardmasterChatRoom findplayer(String name) {
	 	for (int i = 0; i<500;i++) {
	 		//System.out.println(i); {
	 		if (!chatroom[i].dead && !chatroom[i].empty) {
		 		if (!chatroom[i].name1.equals("")) {
		 			if (chatroom[i].name1.equals(name) && chatroom[i].name2wait.equals(this.name)) { roomnumber = i; return chatroom[i]; }
		 		}
		 	}
	 	}	
	 	return null;	
 		
 	}
	 	
 	boolean playerjoinroom (CardmasterChatRoom room, String name, String name2) {
 		if (room.name1.equals("")) {
 			 room.name1 = name;
 			 room.name2wait = name2;
 			 playerroom = room;
 			 this.name = name;
 			 return true;
 		}
 		else if (room.name2wait.equals(name) && room.name1.equals(name2)) { 
 			room.name2wait = "";
 			room.name2 = name;
 			room.empty = false;
 			playerroom = room;
 			room.opfound(roomnumber);
 			this.name = name;
 			return true;
 		} 
 		return false;
 		
 	}
 	
 	
	void threaddie() {
		for (int i = 0; i<500;i++) { // erase yourself from existance.
			if (chatroom[i] != null ) {
				if (chatroom[i].name1.equals(name) || chatroom[i].name2.equals(name) || chatroom[i].name2wait.equals(name)) {
					chatroom[i].name1 = "";
					chatroom[i].name2 = "";
					chatroom[i].name2wait = "";
					chatroom[i].dead = true;	
					
				}	
				
			}
			
		}
		timer.cancel();
		pingtimer.cancel();
	}

	class timerping extends TimerTask   {
		
		
		 public void run() {
		 	try{
		 	if (pingreply == false) {
		 		System.out.println(threadnum + " No reply.. closing.");
		    	if (observer && playerroom != null) playerroom.message("CHA#SYSTEM#" + name + " is no longer observing.");
		   
		    	if (!observer && playerroom != null && !playerroom.ended && !playerroom.dead) playerroom.giveup(name);
			 	else { threaddie(); out.close(); in.close(); socket.close(); }	
		 	}
		 	pingreply = false;
		 	out.println("PNG#");
		 	System.out.println(threadnum + " Ping...");
		 	

		 } catch (Exception e) {
		 	threaddie();
		 	
		 	
		 	
		 	}
		 
	}
		 
	}

	class threadtimer extends TimerTask   {
		
		 public void run() 
    	{    try {
    		    String  outputLine;
			if (playerroom != null && playerroom.dead) {
				out.close();
				in.close();
				socket.close();	
				threaddie(); return;

				
			}

			if (in.ready()) {
				inputLine = in.readLine();
				System.out.println("Recieved from thread " + threadnum + " : " + inputLine );
				StringTokenizer tokenizer = new StringTokenizer(inputLine);
				if (tokenizer.hasMoreTokens()) {
					String command = tokenizer.nextToken("#");
					
					
					if (command.equals("OP") && !observer) {
						pingreply = true;
						String name = tokenizer.nextToken("#");
						String name2 = tokenizer.nextToken("#");
						
						
						boolean keep = true;
						if (name.equals(name2)) {
							out.println("ONF#");
							 out.println("MES#Cant play against self");
							threaddie();
							out.close();
							in.close();
							socket.close();out.println("ONF#"); return;} 
						for (int i = 0; i<500; i++) {
							if (chatroom[i].name1.equals(name)) {
								if (chatroom[i].name2.equals(name)) {
									out.println("ONF#");
									threaddie();
								 	out.close();
							    	in.close();
							    	socket.close();
									keep = false;	
								}
								
							}
							
								
						}
						if (keep) {
							CardmasterChatRoom room = findplayer(name2);
							if (room == null) {
								for (int i = 0; i<500;i++) {
									if (chatroom[i].empty) {
										room = chatroom[i];
										roomnumber = i;
										break;
									}	
								}	
								
								
							}
							
							if (!playerjoinroom(room,name,name2)) {
								
								out.println("ONF#");
								threaddie();
							 	out.close();
						    	in.close();
						    	socket.close();
							}
						}
					}
					else if (command.equals("OB")) { // observer
						
						observer = true; //Observator.
						int room = Integer.parseInt(tokenizer.nextToken("#"));
						
						playerroom = chatroom[room];
						if (!playerroom.dead && !playerroom.empty) {
							
						out.println("OBN#" + playerroom.name1 + "#" + playerroom.name2 + "#");
							name = tokenizer.nextToken();
							playerroom.message("CHA#SYSTEM#" + name + " is observing this game.");
							out.println(playerroom.STN());
							out.println(playerroom.STP());
							out.println(playerroom.STC());
							messagetag = playerroom.messageTag();					
						}
						else {
							out.println("OPF#");
							threaddie();
							out.close();
							in.close();
							socket.close();	
							
						}
					}
					else if (command.equals("DS") && !observer) {
						playerroom.discard_card(name,Integer.parseInt(tokenizer.nextToken("#")));
						
						
					}
					
					else if (command.equals("NP") && !observer) {
						
						playerroom.nextPhase(name);	
						
					}
					else if (command.equals("PM") && !observer) { // Play Monster
						int cardid = Integer.parseInt(tokenizer.nextToken("#"));
						String player = name;
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						int returned = playerroom.play_monster(name,cardid,slot,handslot);
						System.out.println("Returned: " + returned);
						if (returned == 1) {
							playerroom.message(playerroom.STN());
							playerroom.message(playerroom.STP());
							playerroom.message(playerroom.STC());
						//	playerroom.message("MES#Monster played...");
						}
							
						
					}

					else if (command.equals("PE") && !observer) { // Play Effect
						int cardid = Integer.parseInt(tokenizer.nextToken("#"));
						String player = name;
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						if (playerroom.play_effect(name,cardid,slot,handslot) == 1) {
							playerroom.message(playerroom.STN());
							playerroom.message(playerroom.STP());
							playerroom.message(playerroom.STC());
						//	playerroom.message("MES#Effect played...");
						}
							
						
					}
					else if (command.equals("SC") && !observer) {
						String type = tokenizer.nextToken("#");
						int number = Integer.parseInt(tokenizer.nextToken("#"));
						playerroom.sac_card(name,type,number);
						playerroom.message(playerroom.STC());
						playerroom.message(playerroom.STN());
					}
						
					else if (command.equals("CM")) {
						String name = tokenizer.nextToken("#");
						if (observer)
						playerroom.say(name + "(observer)",tokenizer.nextToken("#"));
						else
						playerroom.say(name,tokenizer.nextToken("#"));
						
					}
					else if (command.equals("PN")) {
						pingreply = true;
						System.out.println(threadnum + " Pong...");
						
					}				
				
					else if (command.equals("DB") && !observer) {
							out.println(playerroom.STN());
							out.println(playerroom.STP());
							out.println(playerroom.STC());
						
						
						
					}
					else if (command.equals("BP") && !observer) { // Ability on player
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int target = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						playerroom.do_ability_player(player,slot,slottype,target);
						
					}				

					else if (command.equals("BG") && !observer) { // Ability on graveyard
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int cardid = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						playerroom.do_ability_grave(player,slot,slottype,cardid);
						
					}

					else if (command.equals("AT") && !observer) { // Attack General
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						String player = name;
						playerroom.attack_command(name,slot,0,1);
							
						
					}
					else if (command.equals("AM") && !observer) { // Attack Monster
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int slot2 = Integer.parseInt(tokenizer.nextToken("#"));
						String player = name;
						
						playerroom.attack_command(name,slot,slot2,2);
							
						
					}				
					else if (command.equals("DF") && !observer) { // Defend
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int slot2 = Integer.parseInt(tokenizer.nextToken("#"));
						String player = name;
						
						playerroom.attack_command(name,slot,slot2,3);
							
						
					}
				
					else if (command.equals("BS") && !observer) { // Ability on Slot
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int slot2 = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.do_ability_on_slot(player,slot,slottype,slot2);
							
						
					}				
					else if (command.equals("SS") && !observer) { // Spell on Monster
						int play = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.cast_spell_on_slot(player,  handslot, play);
						
					}
					else if (command.equals("SP") && !observer) { // Spell on Monster
						int play = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.cast_spell_on_player(player,  handslot , play);
						
					}
					else if (command.equals("SA") && !observer) { // Spell on Monster

						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.cast_spell_auto(player, handslot);
						
					}
					else if (command.equals("SG") && !observer) { // Spell on Monster

						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						int cardid = Integer.parseInt(tokenizer.nextToken("#"));
						
						String player= name;
						
						playerroom.cast_spell_grave(player, handslot,cardid);
					}
					else if (command.equals("SM") && !observer) { // Spell on Monster
						int tplayer = Integer.parseInt(tokenizer.nextToken("#"));
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.cast_spell_on_monster(player, handslot, tplayer, slot);
						
					}				
					else if (command.equals("SE") && !observer) { // Spell on Monster
						int tplayer = Integer.parseInt(tokenizer.nextToken("#"));
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int handslot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.cast_spell_on_effect(player, handslot, tplayer, slot);
						
					}
					else if (command.equals("BM") && !observer) { // Ability on Monster
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int tplayer = Integer.parseInt(tokenizer.nextToken("#"));
						int slot2 = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.do_ability_on_monster(player,slot,slottype,tplayer, slot2);
							
						
					}				
					else if (command.equals("BE") && !observer) { // Ability on Monster
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						int tplayer = Integer.parseInt(tokenizer.nextToken("#"));
						int slot2 = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.do_ability_on_effect(player,slot,slottype,tplayer, slot2);
							
						
					}
					else if (command.equals("BA") && !observer) { // Ability on auto
						String slottype = tokenizer.nextToken("#");
						int slot = Integer.parseInt(tokenizer.nextToken("#"));
						String player= name;
						
						playerroom.do_ability_auto(player,slot,slottype);
							
						
					}					
					
					
					
				
				}
				
				
				
				
				
			}
    		if (playerroom != null) {

    			int cmessagetag = messagetag;
			//	System.out.println(threadnum + " : " + playerroom.messageTag() + ">" + messagetag);
		    	if (playerroom.messageTag() >= messagetag) { // send chat message
		    //		for (cmessagetag = messagetag+1;cmessagetag < playerroom.messageTag();cmessagetag++) {
		    		//	System.out.println(messagetag);
		    			
						outputLine = playerroom.getMessage(messagetag); messagetag++;
						if (!(outputLine.startsWith("STC")) && !(outputLine.startsWith("GRA")) && !observer) System.out.println("Sending to thread " + threadnum + " : " + outputLine );
						if (outputLine != null)
						if (!outputLine.equals("null")) out.println(outputLine);
							if (outputLine.startsWith("OVR")) {	
								
		    				threaddie();
			    			out.close();
					    	in.close();
					    	socket.close();
					 		System.out.println(threadnum + " Ending Game");
					    	if (playerroom != null) playerroom.close();			
    				
    						} 					
				//	}
				//messagetag = cmessagetag; 
				}
				
				
    				

    		}	
    		
    } catch (IOException e) {
	    e.printStackTrace();
	}
    		
    		}	
		
		
	}
   
}