package webrunner.cardmaster;
import java.net.*;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.StringTokenizer;

public class CardmasterMatchmakerThread extends Thread{
   CardmasterMatchMaker matchmaker;
   int messagetag = 1;
   int threadnum;
   boolean pingreply;
   boolean success = false;
   Timer timer;
   Timer pingtimer;
   String inputLine = "";
   private Socket socket = null;
   PrintWriter out;
   BufferedReader in;
   String name;
	public CardmasterMatchmakerThread(Socket socket,   CardmasterMatchMaker matchmaker, int threadnum) {
 		super("CardmasterMatchmakerThread");
   		this.matchmaker = matchmaker;
		this.socket = socket;
		this.threadnum = threadnum;
		System.out.println("Matchmaker Thread " +  threadnum + " created.");
 	
 		messagetag = matchmaker.messageTag() + 1;
 	
 	}
 	
	
	  public void run() {
		pingreply = true;
  	 try {
	     out = new PrintWriter(socket.getOutputStream(), true);
	     in = new BufferedReader(
				    new InputStreamReader(
				    socket.getInputStream()));
	

			timer = new Timer();
			timer.schedule(new threadtimer(),0,200);
			pingtimer = new Timer();
			pingtimer.schedule(new timerping(),0,5000);	  	
	  	
	  	
	  	
	  }

	 catch (IOException e) {
	    e.printStackTrace();
	}
   	 
  }
 
	void threaddie() {
		timer.cancel();
		pingtimer.cancel();
		if (name!=null && success) matchmaker.quit(name);
	}

	class timerping extends TimerTask   {
		
		
		 public void run() {
		 	try{
		 	if (pingreply == false) {
		 		System.out.println("Matchmaker " + threadnum + " No reply.. closing.");
		 	 threaddie(); out.close(); in.close(); socket.close(); 
		 	}
		 	pingreply = false;
		 	out.println("PNG#");
		 	System.out.println("Matchmaker " + threadnum + " Ping...");
		 	

		 } catch (Exception e) {}
		 
	}
		 
	}

	class threadtimer extends TimerTask   {
		
		 public void run() 
    		{    try {
    		    String  outputLine;


			if (in.ready()) {
				inputLine = in.readLine();
				System.out.println("Matchmaker Recieved from thread " + threadnum + " : " + inputLine );
	StringTokenizer tokenizer = new StringTokenizer(inputLine);
				if (tokenizer.hasMoreTokens()) {
					String command = tokenizer.nextToken("#");
					
					
					if (command.equals("NAMEIS")) {
						if (tokenizer.hasMoreTokens()) {
							name = tokenizer.nextToken();
							if (!matchmaker.login(name)) {
								out.println("CHASTAT#ERROR: Player already active in matchmaker#");
								threaddie();
				    			out.close();
						    	in.close();
						    	socket.close();
								
								}
								else { success = true; }	
						}
						
					}
					else if (command.equals("CHAT") && success) {
						System.out.println("Chat Message");
						if (tokenizer.hasMoreTokens()) {
							matchmaker.message("CHAT#" + name + "#" + tokenizer.nextToken() + "#", "$all$");	
							
							
						}	
						
						
					}
					
					else if (command.equals("CHALNG")&& success) {
						if (tokenizer.hasMoreTokens()) {
							String challenge = tokenizer.nextToken();
							matchmaker.challenge(name,challenge);	
							
							
						}
						
					}
					else if (command.equals("UNCHAL")&& success) {
						if (tokenizer.hasMoreTokens()) {
							String challenge = tokenizer.nextToken();
							matchmaker.unchallenge(name,challenge);	
							
							
						}
						
					}					
					else if (command.equals("PN") && success) {
						pingreply = true;
						System.out.println("Matchmaker" + threadnum + " Pong...");
						
					}	
				}
			}


     			int cmessagetag = messagetag;
		    	if (matchmaker.messageTag() >= messagetag && success) { // send message

		    			
						outputLine = matchmaker.getMessage(messagetag);
					
						String toname = matchmaker.getToName(messagetag);
						messagetag++;
						System.out.println("Test:" + toname);
						if ((toname.equals("$all$") || (toname.equals(name)))) {
							System.out.println("Sending to " + name + " : " + outputLine );
						
							if (outputLine != null)
							if (!outputLine.equals("null")) out.println(outputLine);
								if (outputLine.startsWith("MATCHMADE") && (toname.equals(name))) {		
			    				threaddie();
				    			out.close();
						    	in.close();
						    	socket.close();
						 		System.out.println(threadnum + " Starting Game....");
						    			
	    				
	    						} 					
						}
				 
				}
				
				
    				

    			
    		
    } catch (IOException e) {
	    e.printStackTrace();
	}
    		
    		}	
		
		
	}
   
}