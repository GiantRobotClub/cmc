package webrunner.cardmaster;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Random;
// Card library/deck
public class CardmasterLibrary {
	public boolean created = false;
	public int cards[];
	public int deck[];
	public int grave[];
public	int numcards = 0;
public	int deckcards = 0;
public int gravecards = 0;
CardmasterUser[] users;
public CardmasterUser user;
	
	public void PrepareDeck() {
		deck = new int[0];
		grave = new int[0];
		for (int i =0; i<cards.length; i++) {
			int[] tempcards = new int[deck.length+1];
			System.arraycopy(deck,0,tempcards,0,deck.length);
			deck = new int[tempcards.length];
			System.arraycopy(tempcards,0,deck,0,tempcards.length);
			deck[i] = cards[i];
	//	System.out.println("Card... " + cards[i]);	
		}
			
		deckcards = numcards;
		shuffleDeck();
	}
	
	
	public void shuffleDeck() {
		Random random = new Random();
		for(int i =0;i<3000;i++) {
			int a = random.nextInt(deckcards-1);
			int b = random.nextInt(deckcards-1);
			int temp = deck[a];
			deck[a] = deck[b];
			deck[b] = temp;
			
		}
		
		
		
	}

	public int getCard(int i) {
		return cards[i];
		
		
		
	}
	public int drawCard() {
		Random random = new Random();
		int a = random.nextInt(deckcards-1);
		int cardid = deck[a];
		//System.out.println(this);
		return drawCard(cardid);
		
	}
	public int drawCard(int id) {
		if (deckcards == 0) return -1; // no cards left.  YOU LOSE, HA HAHAHAHAHAHAHAHAHAHAHAHAHAAHA
		for (int i = 0; i<deckcards; i++) {
			if (deck[i] == id) {
				deck[i] = deck[deckcards-1];
				deck[deckcards-1] = 0;
				deckcards--;
				return id;
			
				
			}
		}
		return 0; // card not found.
	}

	public int drawGrave(int id) {
		if (gravecards == 0) return -1; // no cards left in graveyard
		for (int i = 0; i<gravecards; i++) {
			if (grave[i] == id) {
				grave[i] = grave[gravecards-1];
				grave[gravecards-1] = 0;
				gravecards--;
				int[] tempgrave = new int[gravecards];
				System.arraycopy(grave,0,tempgrave,0,gravecards);
				grave = new int[gravecards];
				System.arraycopy(tempgrave,0,grave,0,gravecards);
				
				return id;
			
				
			}
		}
		return 0; // card not found.
	}


	public int drawGrave() { //pick a random card from Deh Grave.
		Random random = new Random();
		int a = random.nextInt(gravecards-1);
		int cardid = grave[a];
		//System.out.println(this);
		return drawGrave(cardid);
		
	}

	public String toString() {
		String string = "[";
		for (int i = 0; i<numcards;	i++) {
			string = string + cards[i] + ",";
			
			
		}
		string = string + "][";
		for (int i = 0; i<deckcards;	i++) {
			string = string + deck[i] + ",";
			
			
		}
		string = string + "]";		
		return string;
		
		
		
	}
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}
	public boolean hasCard(int id) {
		//System.out.println("lookin for the Card..");
		for (int i = 0;i<cards.length;i++) {
		//	System.out.println("Checking " + cards[i] + " against " + id);
			if (cards[i]==id) return true;
			
		}	
		//System.out.println("not Found");
		return false;
		
		
	}
	public void addCard(int i) {
		int cardid = i;
		int[] tempcards = new int[cards.length+1];
		System.arraycopy(cards,0,tempcards,0,cards.length);
		cards = new int[tempcards.length];
		System.arraycopy(tempcards,0,cards,0,tempcards.length);
		cards[tempcards.length-1] = cardid;
		numcards++;		
		
		
	}

	public void addGrave(int i) {
		int cardid = i;
		int[] tempcards = new int[grave.length+1];
		System.arraycopy(grave,0,tempcards,0,grave.length);
		grave = new int[tempcards.length];
		System.arraycopy(tempcards,0,grave,0,tempcards.length);
		grave[tempcards.length-1] = cardid;
		gravecards++;	
		
		
	}

	public void addPlayDeck(int i) {
		int cardid = i;
		int[] tempcards = new int[deck.length+1];
		System.arraycopy(deck,0,tempcards,0,deck.length);
		deck = new int[tempcards.length];
		System.arraycopy(tempcards,0,deck,0,tempcards.length);
		deck[tempcards.length-1] = cardid;
		deckcards++;		
		
		
	}
	
	public boolean takeCard(int id) {
		if (numcards == 0) return false;
		if (cards.length == 1) return false; // no clearing a deck, I'm afraid.
		for (int i = 0; i<numcards; i++) {
			if (cards[i] == id) {
				cards[i] = cards[numcards-1];
				int[] tempcards = new int[cards.length-1];
				System.arraycopy(cards,0,tempcards,0,cards.length-1);
				cards = new int[tempcards.length];
				System.arraycopy(tempcards,0,cards,0,tempcards.length);
				numcards--;
				return true;
			
				
			}
		}
		return false; // card not found.
	}
	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	

	CardmasterLibrary() { //empty library
		cards = new int[0];
		int numcards = 0;
		int deckcards =0;
		
		
		}	
	CardmasterLibrary(String name) {
		cards = new int[0];
		int currentcard = 0;
		
		loadUserData();
		int id;
		if (loadUser(name)) {
			id = user.primarydeck;	
			
			
			
		}
		else id = -1; 
		if (id != -1) created = true;
		try{
		String inputLine;
		FileReader reader = new FileReader(CardmasterData.DIRECTORY +"decks/deck_" + id + ".csc");
		BufferedReader in = new BufferedReader(reader);
		while ((inputLine = in.readLine()) != null) {
			int cardid = Integer.parseInt(inputLine);
			int[] tempcards = new int[cards.length+1];
			System.arraycopy(cards,0,tempcards,0,cards.length);
			cards = new int[tempcards.length];
			System.arraycopy(tempcards,0,cards,0,tempcards.length);
			cards[currentcard] = cardid;
			//System.out.println("added " + cardid + " for " + name);
			currentcard++;
			numcards++;	
				
		}
		
		
		java.util.Arrays.sort(cards);	
		reader.close();
			
    } catch (Exception e) {
    	e.printStackTrace();}	
		
		
	}
	
	CardmasterLibrary(String name, int id) {
		cards = new int[0];
		int currentcard = 0;
		loadUserData();
		//int id;
		loadUser(name);
		try{
		String inputLine;
		FileReader reader = new FileReader(CardmasterData.DIRECTORY +"decks/deck_" + id + ".csc");
		BufferedReader in = new BufferedReader(reader);
		while ((inputLine = in.readLine()) != null) {
			int cardid = Integer.parseInt(inputLine);
			int[] tempcards = new int[cards.length+1];
			System.arraycopy(cards,0,tempcards,0,cards.length);
			cards = new int[tempcards.length];
			System.arraycopy(tempcards,0,cards,0,tempcards.length);
			cards[currentcard] = cardid;
			//System.out.println("added " + cardid + " for " + name);
			currentcard++;
			numcards++;	
				
		}
		
		java.util.Arrays.sort(cards);
		
		reader.close();
			
    } catch (Exception e) {
    	e.printStackTrace();}	
		
		
	}
	
		
	
	CardmasterLibrary(int id) {
		try {
		cards = new int[0];
		int currentcard = 0;
		FileReader reader = new FileReader(CardmasterData.DIRECTORY +"decks/deck_" + id + ".csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while ((inputLine = in.readLine()) != null) {
			int cardid = Integer.parseInt(inputLine);
			int[] tempcards = new int[cards.length+1];
			System.arraycopy(cards,0,tempcards,0,cards.length);
			cards = new int[tempcards.length];
			System.arraycopy(tempcards,0,cards,0,tempcards.length);
			cards[currentcard] = cardid;			currentcard++;
			numcards++;
				
		}
		
		
		java.util.Arrays.sort(cards);
		reader.close();
		 } catch (Exception e) {
		 	System.out.println("WOOPS");
		 	e.printStackTrace();}	
	}
	
	
	
	
	
	
	
}