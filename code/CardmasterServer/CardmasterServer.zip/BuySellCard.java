package webrunner.cardmaster;
import java.util.StringTokenizer;
import java.io.*;
public class BuySellCard {
	CardmasterUser[] users;
	CardmasterUser user;
		
	
		CardmasterServerCard carddata[];
		public void loadCardData() {
		carddata = new CardmasterServerCard[CardmasterData.NUMBER_OF_CARDS];
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "cards.csc");
			BufferedReader in = new BufferedReader(reader);
			
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
				if (cardid >= 10) carddata[cardid] = new CardmasterServerCard(inputLine);
				
		//	System.out.println(carddata[cardid]);
				
				
			}
			
			
			reader.close();
			
			
		}
		catch (Exception e) {
			e.printStackTrace();}	
		
		
	}
	
	public boolean killDeck(String name, int deck1) {
		if (!loadUser(name)) return false;
		if ((!(user.hasDeck(deck1)) )) return false;
		if (user.primarydeck == deck1) return false;
		userpatch(name,"remd",deck1,"x");
		File file = new File(CardmasterData.DIRECTORY + "decks/deck_" + deck1 + ".csc");
		if (file.exists()) { file.delete(); return true; } 
		return false;
		
	}	
	// move card from deck1, to deck2.

	public int buyCard(int deck2,String name, int card) {
		loadUserData();
		if (!loadUser(name)) return 0;
		int deck1 = 99999;
		if ((!(user.hasDeck(deck2)) )) return 0;
		
		CardmasterLibrary deckone = new CardmasterLibrary(deck1);
		CardmasterLibrary decktwo = new CardmasterLibrary(deck2);
		
		if (!(deckone.hasCard(card))) return 0;
		if (!(deckone.takeCard(card))) return 0;
		
		decktwo.addCard(card);
		int rarity = 101 - carddata[card].printed;
		int price = (int)(rarity * Math.sqrt(rarity) / 2) + 1 ;	
		if (user.points < price) return 0;
		userpatch(name,"remp",price,"x");
		try{
		
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck1 + ".csc");
		PrintWriter out = new PrintWriter(writer);
		for(int i =0;i<deckone.numcards;i++) {
			if (i < deckone.numcards-1) out.println(deckone.cards[i]);	
			else out.print(deckone.cards[i]);
			
			
		}
		
		
		out.close();

		 writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck2 + ".csc");
	 out = new PrintWriter(writer);
		for(int i =0;i<decktwo.numcards;i++) {
			if (i < decktwo.numcards-1) out.println(decktwo.cards[i]);	
			else out.print(decktwo.cards[i]);
			
			
		}
		
		
		out.close();
		
		return price;	
		}catch(Exception e) {
		e.printStackTrace();
		System.out.println("******EXCEPTION*********");
		return 0; }
		
		
	}
	
	public int sellCard(int deck1,String name, int card) {
		loadUserData();
		if (!loadUser(name)) return 0;
		int deck2 = 99999;
		if ((!(user.hasDeck(deck1)) )) return 0;
		
		CardmasterLibrary deckone = new CardmasterLibrary(deck1);
		CardmasterLibrary decktwo = new CardmasterLibrary(deck2);
		if (deckone.numcards == 1) return 0;
		if (!(deckone.hasCard(card))) return 0;
		if (!(deckone.takeCard(card))) return 0;
		
		decktwo.addCard(card);
		int rarity = 101 - carddata[card].printed;
		int price = ((int)(rarity * Math.sqrt(rarity) / 2) + 2)/8 + 1 ;	
		userpatch(name,"addp",price,"x");
		try{
		
		FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck1 + ".csc");
		PrintWriter out = new PrintWriter(writer);
		for(int i =0;i<deckone.numcards;i++) {
			if (i < deckone.numcards-1) out.println(deckone.cards[i]);	
			else out.print(deckone.cards[i]);
			
			
		}
		
		
		out.close();

		 writer = new FileWriter(CardmasterData.DIRECTORY + "decks/deck_" + deck2 + ".csc");
	 out = new PrintWriter(writer);
		for(int i =0;i<decktwo.numcards;i++) {
			if (i < decktwo.numcards-1) out.println(decktwo.cards[i]);	
			else out.print(decktwo.cards[i]);
			
			
		}
		
		
		out.close();
		
		return price;	
		}catch(Exception e) {
		e.printStackTrace();
		System.out.println("******EXCEPTION*********");
		return 0; }
		
		
	}
	
	
	
	
	public	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	public boolean userpatch(String name, String command, int amount, String text) {
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "userpatch.csc", true); 
			PrintWriter out = new PrintWriter(writer);
			//out.print(users[1]);
			out.println(name + ":" + command + ":" + text + ":" + amount + ":");
			out.close();
			return true;
	}catch(Exception e) {}
		return false;
	}
	public boolean loadUser(String name) {
		for (int i=0;i<users.length;i++) {
			if (users[i] != null)
			if (users[i].name.equals(name)) {
				user = users[i];
			//	loadDecks();
				return true;
				
			}
			
			
		}
		return false;
		
		
	}	
}