package webrunner.cardmaster;
import java.io.*;
import java.util.StringTokenizer;
public class CardmasterShowDeckBean {
	private String name;
CardmasterLibrary deck;
	

	CardmasterServerCard carddata[];
	void loadCardData() {
		carddata = new CardmasterServerCard[CardmasterData.NUMBER_OF_CARDS];
		try {
			FileReader reader = new FileReader(CardmasterData.DIRECTORY + "cards.csc");
			BufferedReader in = new BufferedReader(reader);
			
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(inputLine,"#");
				int cardid = Integer.parseInt(token.nextToken());
				if (cardid >= 10) carddata[cardid] = new CardmasterServerCard(inputLine);
				
			//System.out.println(carddata[cardid]);
				
				
			}
			
			
			reader.close();
			
			
		}
		catch (Exception e) {
			e.printStackTrace();}	
		
		
	}


	public boolean loadData(int decknumber)  {
	//	System.out.println("TEST");
	 if(decknumber != 0) {
	 	deck = new CardmasterLibrary(name,decknumber);
	 	if ((!(deck.user.hasDeck(decknumber))) && decknumber!=99999 ) return false; // allow you to see the deck'o'stuff to buy.
	 	
	 }
	 else deck = new CardmasterLibrary(name);
		//if (deck.fault) return false;
		loadCardData();
		return true;
		
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;	
		
	}

	public int getDeckSize() {
		return deck.numcards;
	}
	
	public int getCommonness(int i) {
		int cardid = deck.getCard(i);
		if (!carddata[cardid].dummy) return (carddata[cardid].printed);
		else return 0;
	}
	public int getRarity(int i) {
		int common = getCommonness(i);
		int rarity = 101 - common;
		return rarity;		
	}
	public int getBuyCost(int i) {
		int rarity = getRarity(i);
		return (int)(rarity * Math.sqrt(rarity) / 2) + 1 ;	
	}
	public int getSellCost(int i) {
		int rarity = getRarity(i);
		return (int)((getBuyCost(i) + 1) / 8) + 1;	
		
	}
	public String getCardName(int i) {
	//	System.out.println("Getting" + i);
		int cardid = deck.getCard(i);
		if (!carddata[cardid].dummy) return (carddata[cardid].name);
		else return ("Dummy Card");
		
		
	}
	
	public String getImage(int i) {
		int cardid = deck.getCard(i);
		if (!carddata[cardid].dummy) return ("cardpics/" + carddata[cardid].picture);	
		else return ("x");
		
	}
	public int getCardID(int i) {
		return deck.getCard(i);
		
	}	
	public String getManaCost(int i) {
		int cardid = deck.getCard(i);
			if (!carddata[cardid].dummy) 
				return (carddata[cardid].Dcost) + "D " 
				+ (carddata[cardid].Lcost) + "L " 
				+ (carddata[cardid].Gcost) + "G ";
		else return("0D 0L 0G");	
	}
	
	public String getBackColor(int i) {
	//	System.out.println(i);
		int cardid = deck.getCard(i);
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].colorcode == 2) return "#7C015A";
			if (carddata[cardid].colorcode == 4) return "white";
			if (carddata[cardid].colorcode == 8) return "#D4D4D4";

		}	
		
		return "#C4C4C4";
	}	
	public String getTextColor(int i) {	int cardid = deck.getCard(i);
		if (!carddata[cardid].dummy) {
			if (carddata[cardid].colorcode == 2) return "orange";
			if (carddata[cardid].colorcode == 4) return "black";
			if (carddata[cardid].colorcode == 8) return "#444444";
				
				
				
		}	
		
		return "black";
	}	

}

