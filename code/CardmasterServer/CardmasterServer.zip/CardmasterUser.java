package webrunner.cardmaster;
import java.util.StringTokenizer;
public class CardmasterUser {
	public int primarydeck;
	public int[] decks; // implement later.
	public String name;
	public String password;
	public int points;
	public int wins;
	public int losses;
	public boolean equals(CardmasterUser user) {
		if (user.name.equals(name)) return true;
		else return false;	
		
		
	}

	CardmasterUser(String data) {
			
	
		decks = new int[1];
		StringTokenizer tokenizer = new StringTokenizer(data,":");
		tokenizer.nextToken(); // name:
		name = tokenizer.nextToken(); //actual name
		tokenizer.nextToken(); // password
		password = tokenizer.nextToken(); //actual password
		tokenizer.nextToken(); // decks
		String decklist = tokenizer.nextToken(); // deck list
		StringTokenizer token = new StringTokenizer(decklist,".");
			while (token.hasMoreTokens()) {
				addDeck(Integer.parseInt(token.nextToken()));		
				
			}
		
		
		
		tokenizer.nextToken(); // primary	
		primarydeck = Integer.parseInt(tokenizer.nextToken());		
		tokenizer.nextToken(); // points
		points = Integer.parseInt(tokenizer.nextToken());
		//System.out.println(name + " has points " + points);
		tokenizer.nextToken(); // wins
		wins = Integer.parseInt(tokenizer.nextToken());
		tokenizer.nextToken(); // losses
		losses = Integer.parseInt(tokenizer.nextToken());
		
		
	}	

	
	CardmasterUser(String name, String password) {
		this.name = name;
		this.password = password;
		wins = 0;
		losses = 0;
		points = 1000;
		
		decks = new int[1];
		
	}
	//name:webrunner:pass:online10:decks:1.:primary:1:
	public String toString() {
		String decklist = "";
		for (int i=1;i<decks.length;i++) {
			if (i!=1) decklist = decklist + ".";
			decklist = decklist + decks[i];	
		}
		return ("name:" + name + ":pass:" + password + ":decks:" + decklist + ".:primary:" + primarydeck + ":points:" + points + ":wins:" +wins +":loss:" +losses + ":");
		
		
	}
	public boolean setPrimaryDeck(int i) {
		if (hasDeck(i)) {
			primarydeck = i;
			return true;}
		else return false;	
		
	}
	public boolean addDeck(int i) {
		if (!hasDeck(i)) {
			int[] tempdeck = new int[decks.length +1];
			System.arraycopy(decks,0,tempdeck,0,decks.length);
			tempdeck[decks.length] = i;
			decks = new int[decks.length +1];
			System.arraycopy(tempdeck,0,decks,0,tempdeck.length);
			return true;
		}
		return false;
		
	}
	public boolean hasDeck(int d) {
		for (int i =1;i<decks.length;i++) {
			if (decks[i] == d) return true;
			
			}	
		return false;
		
	}
	public void removeDeck(int d) {
		int i;
		if (primarydeck == d) return;
		for (i =1;i<decks.length;i++) {
			if (decks[i] == d) {
				decks[i] = decks[decks.length-1];
				int[] tempdeck = new int[decks.length -1];
				System.arraycopy(decks,0,tempdeck,0,tempdeck.length);
				decks = new int[decks.length-1];
				System.arraycopy(tempdeck,0,decks,0,tempdeck.length);
				return;
				
			}
			
			
		}	
		
		
	}

	
	
	
	
	
	
	
	
}