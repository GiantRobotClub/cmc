package webrunner.cardmaster;
import java.io.*;
public class CardmasterLogin{
	String username;
	String password;
	
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPassword(String password) {
		this.password = password;	
		
	}
	CardmasterUser users[];
	CardmasterUser user;
	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	public boolean Login() {
		loadUserData();
		for (int i = 1;i<users.length;i++) {
			System.out.println(username + " " + users[i].name + " " + password + " " + users[i].password);
			if (users[i].name.equals(username) && users[i].password.equals(password)) {
				return true;
			}
		}
		
		return false;
		
	}	
	
	
	
	
	
}