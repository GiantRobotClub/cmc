package webrunner.cardmaster;
import java.io.*;


public class CardmasterUserFactory {
	String username;
	String password;
	String decknumber;	
	CardmasterUser users[];
	CardmasterUser user;
	
	public void setUsername(String name) {
		username = name;	
		
	}
	public void setPassword(String pass) {
		System.out.println("Setting password to " + pass);	
		password = pass;
	}
	public void setDeckNumber(String number) {
		decknumber = number;	
		
	}
	public boolean createUserFromData() {
		loadUserData();	
		if (decknumber.equals("-1")) return false;
		if (userAlreadyExists(username)) return false;
		if (!validName(username)) return false;
		user = new CardmasterUser(username,password);
		if (!user.addDeck(Integer.parseInt(decknumber))) return false;
		if (!user.setPrimaryDeck(Integer.parseInt(decknumber))) return false;

		return true;
		
	}
	
	
	public boolean saveUser() {
		try{
			FileWriter writer = new FileWriter(CardmasterData.DIRECTORY + "users.csc", true); // append
			PrintWriter out = new PrintWriter(writer);
			File file = new File(CardmasterData.DIRECTORY + "users.csc");
			if (file.length() > 1) out.print(System.getProperty("line.separator"));
			out.print(user);
			out.close();
			return true;
		}catch(Exception e){ return false;}
		
		
	}
	public boolean userAlreadyExists(String name) {

		for (int i = 1;i<users.length;i++) {
		//	System.out.println(name + " against " + users[i].name);
			if (users[i].name.equals(name)) {
			//	System.out.println("THE SAME");
				return true;
			}
		}
		
		return false;
		
	}
	public boolean validName(String name) {
		if (name.indexOf("#") != -1) return false;
		if (name.indexOf("^") != -1) return false;
		if (name.indexOf(":") != -1) return false;
		if (name.indexOf(".") != -1) return false;
		
		return true;	
		
		
	}
	
	public void deleteFile() {
		File file = new File(CardmasterData.DIRECTORY + "decks/deck_" + decknumber + ".csc");
		if (file.exists()) file.delete();
			
		
	}
	void loadUserData() {
		try{
		users = new CardmasterUser[1];
		FileReader reader = new FileReader(CardmasterData.DIRECTORY + "users.csc");
		BufferedReader in = new BufferedReader(reader);
		String inputLine;
		while (((inputLine = in.readLine()) != null)) {
			CardmasterUser[] tempusers = new CardmasterUser[users.length + 1];
			System.arraycopy(users,0,tempusers,0,users.length);
		//	System.out.println("Line " + inputLine);
			tempusers[users.length] = new CardmasterUser(inputLine);
			users = new CardmasterUser[tempusers.length];
			System.arraycopy(tempusers,0,users,0,tempusers.length);

		}
		
	in.close();	 	}catch(Exception e){}
	}
	

}