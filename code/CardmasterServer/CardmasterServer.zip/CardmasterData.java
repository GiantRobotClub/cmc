

package webrunner.cardmaster;

public class CardmasterData {
		static String DIRECTORY = "/cmcdata/";
		static int NUMBER_OF_CARDS = 200;	
	
}